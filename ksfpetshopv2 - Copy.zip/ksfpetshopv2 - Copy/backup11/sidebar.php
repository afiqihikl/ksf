<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
include 'notification.php';
$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>

    <!-- ✅ Bootstrap 5.3.0 (CSS & JS) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- ✅ Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- ✅ DataTables CSS & JS -->
    <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css"> -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <!-- <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script> -->
    <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.css" />
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>

    <!-- modal -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: rgb(0, 25, 67);
            padding: 10px 20px;
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
        }

        .nav-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 5px;
            /* bagi ruang antara cart dan dropdown */
        }

        .logo {
            font-size: 20px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }

        .navbar .icon {
            font-size: 24px;
            font-weight: bold;
            cursor: pointer;
            color: rgb(199, 156, 2);
        }

        .navbar .links {
            display: flex;
            gap: 0;
        }

        .navbar .links a {
            text-decoration: none;
            color: white;
            padding: 5px 10px;
            transition: background-color 0.3s;
            color: rgb(199, 156, 2);
        }

        .navbar .links a:hover {
            background-color: rgb(1, 16, 43);
            border-radius: 5px;
        }

        .sidebar {
            width: 180px;
            height: 100vh;
            background-color: rgb(0, 25, 67);
            color: white;
            position: fixed;
            top: 64px;
            left: 0;
            display: flex;
            flex-direction: column;
            padding: 0;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .sidebar.collapsed {
            transform: translateX(-240px);
        }

        .sidebar a {
            color: rgb(199, 156, 2);
            text-decoration: none;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgb(1, 16, 43);
        }

        .content {
            margin-left: 180px;
            padding: 50px 20px;
            transition: margin-left 0.3s ease;
        }

        .content.collapsed {
            margin-left: 0;
        }

        .toast-container {
            position: fixed;
            top: 70px;
            right: 20px;
            z-index: 2000;
        }

        .toast {
            min-width: 250px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }


        .notification-wrapper {
            position: relative;
            display: inline-block;
        }

        .notification-wrapper .badge {
            position: absolute;
            top: -6px;
            right: -10px;
            background: linear-gradient(135deg, #ff3c3c, #c20a0a);
            color: #fff;
            font-size: 9px;
            padding: 2px 5px;
            border-radius: 50%;
            font-weight: bold;
            min-width: 16px;
            min-height: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 6px rgba(0, 0, 0, 0.3);
            animation: pulse 1.5s infinite;
        }


        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* The dropdown button */
        .dropdown-button {
            background-color: rgb(0, 25, 67);
            /* Green background */
            color: white;
            padding: 10px 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 8px;
            color: rgb(199, 156, 2);
        }

        /* Dropdown menu */
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            /* Align to the right */
            background-color: white;
            min-width: 180px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.15);
            z-index: 1;
            border-radius: 8px;
            overflow: hidden;
        }

        /* Individual menu item */
        .dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            font-size: 15px;
        }

        /* Hover styles */
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        /* Show the dropdown on hover */
        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Optional: Hover effect for button */
        .dropdown:hover .dropdown-button {
            background-color: rgb(0, 25, 67);
        }


        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .content {
                margin-left: 0;
            }

            .navbar {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>

<body>
    <div class="navbar">
        <div class="nav-left">
            <div class="icon" onclick="toggleSidebar()">
                <i class="fa fa-bars"></i>
            </div>
            <a href="index.php" class="logo" style="color: rgb(199, 156, 2); text-decoration: none">KSF PETSHOP</a>
        </div>
        <div class="nav-right">
            <div class="dropdown">
                <button type="button" class="dropdown-button" onclick="window.location.href='new_sales.php'">
                    <i class="fa fa-shopping-cart"></i>
                </button>
            </div>
            <div class="dropdown">
                <button type="button" class="dropdown-button" onclick="toggleStockDropdown()">
                    <div class="notification-wrapper">
                        <i class='fas fa-bell'></i>
                        <?php if ($low_stock_count > 0): ?>
                            <span class="badge"><?= $low_stock_count ?></span>
                        <?php endif; ?>
                    </div>
                </button>
                <div class="dropdown-content" id="myDropdown">
                    <?php if ($low_stock_count > 0): ?>
                        <?php foreach ($low_stock_products as $product): ?>
                            <a class="dropdown-item" href="#">
                                <?= htmlspecialchars($product['product_title']) ?> - <strong><?= $product['in_stock'] ?></strong> left
                                <br><small class="text-muted"><?= htmlspecialchars($product['product_code']) ?></small>
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <span class="dropdown-item text-muted">All stocks are sufficient.</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="dropdown">
                <button type="button" class="dropdown-button" onclick="toggleDropdown()">
                    <i style="color: rgb(199, 156, 2);" class="fas fa-user-alt"></i>
                </button>
                <div class="dropdown-content" id="myDropdown">
                    <a class="dropdown-item" href="#">Link 1</a>
                    <a class="dropdown-item" href="#">Link 2</a>
                    <a class="dropdown-item" href="#">Link 3</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" style="text-align: end;" href="logout.php">Logout <i class="fas fa-power-off"></i>
                    </a>
                </div>
            </div>
        </div>

    </div>

    <div class="sidebar" id="sidebar">
        <a href="index.php" class="<?= $current_page === 'index.php' ? 'active' : '' ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
        <a href="category.php" class="<?= $current_page === 'category.php' ? 'active' : '' ?>"><i class="fa fa-list-alt"></i> Category</a>
        <a href="vendor.php" class="<?= $current_page === 'vendor.php' ? 'active' : '' ?>"><i class="fa fa-truck"></i> Vendors</a>
        <a href="product.php" class="<?= $current_page === 'product.php' ? 'active' : '' ?>"><i class="fa fa-archive"></i> Product</a>
        <a href="sales.php" class="<?= $current_page === 'sales.php' ? 'active' : '' ?>"><i class="fa fa-dollar"></i> Sales</a>
        <a href="invoice.php" class="<?= $current_page === 'invoice.php' ? 'active' : '' ?>"><i class="fa-solid fa-file-invoice-dollar"></i> Invoice</a>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const content = document.getElementById('content');

            sidebar.classList.toggle('collapsed');
            if (content) {
                content.classList.toggle('collapsed');
            }
        }
    </script>

</body>

</html>