<?php
include 'db.php';

if (!isset($_GET['invoice_id'])) {
    die("Invoice ID is missing.");
}

$invoice_id = intval($_GET['invoice_id']);

$invoice = $pdo->prepare("SELECT i.*, u.username 
                          FROM invoices i 
                          JOIN users u ON i.user_id = u.user_id 
                          WHERE i.invoice_id = ?");
$invoice->execute([$invoice_id]);
$invoice = $invoice->fetch();

if (!$invoice) {
    die("Invoice not found.");
}

$items = $pdo->prepare("SELECT ii.*, p.product_title 
                        FROM invoice_items ii 
                        JOIN products p ON ii.product_id = p.product_id 
                        WHERE ii.invoice_id = ?");
$items->execute([$invoice_id]);
$items = $items->fetchAll();
?>
<!DOCTYPE html>
<html>

<head>
    <title>Invoice Receipt</title>
    <style>
        body {
            font-family: monospace;
            max-width: 300px;
            margin: auto;
        }

        .center {
            text-align: center;
        }

        .bold {
            font-weight: bold;
        }

        .line {
            border-top: 1px dashed #000;
            margin: 8px 0;
        }

        .right {
            text-align: right;
        }

        @media print {
            button {
                display: none;
            }
        }
    </style>
    <script>
        window.onload = function() {
            // Auto-print when page loads
            window.print();

            // Optional: close window after print (uncomment if needed)
            window.onafterprint = function() {
                window.close();
            };
        };
    </script>
</head>

<body>
    <div class="center">
        <h2><?= htmlspecialchars($invoice['company_name']) ?></h2>
        <p>Invoice #: <?= $invoice['invoice_number'] ?><br>
            Date: <?= date('Y-m-d H:i', strtotime($invoice['invoice_date'])) ?><br>
            Cashier: <?= htmlspecialchars($invoice['username']) ?></p>
    </div>

    <div class="line"></div>
    <?php foreach ($items as $item): ?>
        <div>
            <div><?= htmlspecialchars($item['product_title']) ?></div>
            <div class="right">
                <?= $item['quantity'] ?> x RM<?= number_format($item['price'], 2) ?> =
                RM<?= number_format($item['total'], 2) ?>
            </div>
        </div>
    <?php endforeach; ?>
    <div class="line"></div>
    <div class="right bold">TOTAL: RM<?= number_format($invoice['total_amount'], 2) ?></div>
    <div class="center line">Thank you!</div>
</body>

</html>