<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $category_id = $_POST['category_id'];
        $category_name = htmlspecialchars($_POST['category_name']);

        if (!empty($category_id) && !empty($category_name)) {
            $sql = "UPDATE category SET category_name = :category_name WHERE category_id = :category_id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':category_id' => $category_id,
                ':category_name' => $category_name
            ]);

            // Redirect with success message
            header("Location: category.php?success=Category updated successfully!");
            exit();
        } else {
            header("Location: category.php?error=Category name cannot be empty.");
            exit();
        }
    } catch (PDOException $e) {
        // Redirect with error message
        header("Location: category.php?error=Error updating category: " . $e->getMessage());
        exit();
    }
} else {
    // Redirect if accessed directly
    header("Location: category.php");
    exit();
}
?>
