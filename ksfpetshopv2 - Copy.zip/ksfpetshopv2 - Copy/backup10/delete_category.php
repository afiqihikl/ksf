<?php
session_start();
include 'db.php';
include 'toast.php';

if (isset($_GET['id'])) {
    $category_id = $_GET['id'];

    try {
        // Delete category from database
        $stmt = $pdo->prepare("DELETE FROM category WHERE category_id = :category_id");
        $stmt->execute([':category_id' => $category_id]);
        // ✅ Set success toast in session
        $_SESSION['toast_message'] = "Category deleted successfully!";
        $_SESSION['toast_type'] = "success";
    } catch (PDOException $e) {
        $_SESSION['toast_message'] = "Error deleting category: " . $e->getMessage();
        $_SESSION['toast_type'] = "danger";
    }
} else {
    $_SESSION['toast_message'] = "Invalid category ID.";
    $_SESSION['toast_type'] = "warning";
}

// Redirect to category.php
header("Location: category.php");
exit;
