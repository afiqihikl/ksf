<?php
include 'db.php';
include 'sidebar.php';

// Fetch sales data using correct schema
$query = "SELECT s.sale_id, p.product_title, si.quantity, si.total, s.sale_date 
          FROM sale_items si
          JOIN products p ON si.product_id = p.product_id
          JOIN sales s ON si.sale_id = s.sale_id
          ORDER BY s.sale_date DESC";

$stmt = $pdo->prepare($query);
$stmt->execute();
$sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.css" />
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">SALES</h1>

        <div class="row">
            <div class="col-12">
                <div class="card" style="height:100%">
                    <div class="card-header">
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-primary" onclick="window.location='new_sales.php'"><i class='fa fa-plus-circle'></i> Add Sales</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table id="ksfTable1" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Product Title</th>
                                        <th>Quantity</th>
                                        <th>Total Price (RM)</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($sales as $index => $row): ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td><?= htmlspecialchars($row['product_title']) ?></td>
                                            <td><?= htmlspecialchars($row['quantity']) ?></td>
                                            <td>RM<?= number_format($row['total'], 2) ?></td>
                                            <td><?= htmlspecialchars($row['sale_date']) ?></td>
                                            <td>
                                                <a href="delete_sales.php?id=<?= $row['sale_id'] ?>"
                                                    class="btn btn-sm btn-danger"
                                                    title="Delete"
                                                    onclick="return confirm('Are you sure?')">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>

</html>