<?php
ob_start();
include 'db.php';
include 'sidebar.php';
include 'toast.php';
include 'modal.php'; // ✅ Include modal.php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php displayToast(); ?>
    <div class="content" id="content">
        <h1 class="mt-4">VENDOR</h1>
        <div class="row">
            <div class="col-12">
                <div class="card" style="height:100%">
                    <div class="card-header">
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-primary" onclick="window.location='new_vendor.php'"><i class='fa fa-plus-circle'></i> New Vendor</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Vendor Name</th>
                                        <th>Status</th>
                                        <th>Contact</th>
                                        <th>Address</th>
                                        <th>PIC</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    try {
                                        $stmt = $pdo->query("SELECT * FROM vendors");
                                        $counter = 1;
                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                            echo "<tr>";
                                            echo "<td>" . $counter++ . "</td>";
                                            echo "<td>" . htmlspecialchars($row['vendor_name']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['vendor_status']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['vendor_contact']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['vendor_address']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['vendor_personincharge']) . "</td>";
                                            echo "<td style='width:170px;'>
                                                    <button class='btn btn-secondary btn-sm open-modal' 
                                                        data-id='{$row['vendor_id']}' 
                                                        data-name='{$row['vendor_name']}' 
                                                        data-status='{$row['vendor_status']}' 
                                                        data-contact='{$row['vendor_contact']}' 
                                                        data-address='{$row['vendor_address']}' 
                                                        data-pic='{$row['vendor_personincharge']}'>
                                                        <i class='fa fa-edit'></i> Edit
                                                    </button>
                                                    <button class='btn btn-danger btn-sm open-modal' 
                                                            data-id='{$row['vendor_id']}' 
                                                            data-name='{$row['vendor_name']}'>
                                                        <i class='fa fa-trash-o'></i> Delete
                                                    </button>
                                                  </td>";
                                            echo "</tr>";
                                        }
                                    } catch (PDOException $e) {
                                        echo "<tr><td colspan='7'>Error fetching data: " . $e->getMessage() . "</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $(".toast").toast("show");

            // Handle edit and delete button click
            $(document).on("click", ".open-modal", function() {
                
                let vendor_id = $(this).data("id");
                let vendor_name = $(this).data("name");
                let vendor_status = $(this).data("status");
                let vendor_contact = $(this).data("contact");
                let vendor_address = $(this).data("address");
                let vendor_pic = $(this).data("pic") || '';

                let isEdit = $(this).hasClass("btn-secondary"); // Check if it's the Edit button
                let isDelete = $(this).hasClass("btn-danger"); // Check if it's the Delete button

                if (isEdit) {
                    $("#modalTitle").text("Edit Vendor");
                    $("#modalBody").html(`
                    <form action="update_vendor.php" method="POST">
                        <input type="hidden" name="vendor_id" value="${vendor_id}">
                        <div class="form-group">
                            <label for="vendor_name">Vendor Name:</label>
                            <input type="text" class="form-control" name="vendor_name" value="${vendor_name}" required>
                        </div>
                        <div class="form-group">
                            <label for="vendor_status">Status:</label>
                            <select class="form-control" name="vendor_status">
                                <option value="Active" ${vendor_status === 'Active' ? 'selected' : ''}>Active</option>
                                <option value="Inactive" ${vendor_status === 'Inactive' ? 'selected' : ''}>Inactive</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="vendor_contact">Contact:</label>
                            <input type="text" class="form-control" name="vendor_contact" value="${vendor_contact}" required>
                        </div>
                        <div class="form-group">
                            <label for="vendor_address">Address:</label>
                            <input type="text" class="form-control" name="vendor_address" value="${vendor_address}" required>
                        </div>
                        <div class="form-group">
                            <label for="vendor_personincharge">PIC:</label>
                            <input type="text" class="form-control" name="vendor_personincharge" value="${vendor_pic}" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    </form>
                `);
                    $("#modalFooter").html(""); // Clear footer
                } else if (isDelete) {
                    $("#modalTitle").text("Confirm Deletion");
                    $("#modalBody").html(`<p>Are you sure you want to delete this vendor?</p>`);
                    $("#modalFooter").html(`
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <a href="delete_vendor.php?id=${vendor_id}" class="btn btn-danger">Delete</a>
                `);
                }

                // Show the modal
                $("#universalModal").modal("show");
            });
        });
    </script>


</body>

</html>