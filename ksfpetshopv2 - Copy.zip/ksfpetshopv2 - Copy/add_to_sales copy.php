<?php
include 'db.php';

// Read raw JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Check valid JSON
if (!$data || !isset($data['cart'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}

$cart = $data['cart'];

try {
    $pdo->beginTransaction();

    // Insert into sales table
    $stmt = $pdo->prepare("INSERT INTO sales (sale_date) VALUES (NOW())");
    $stmt->execute();
    $sale_id = $pdo->lastInsertId();

    // Loop through each cart item
    foreach ($cart as $item) {
        $product_id = intval($item['id']);
        $quantity = intval($item['quantity']);
        $price = floatval($item['price']);
        $total = $quantity * $price;

        // Validate product exists
        $check = $pdo->prepare("SELECT * FROM products WHERE product_id = ?");
        $check->execute([$product_id]);
        $product = $check->fetch();

        if (!$product) {
            throw new Exception("Product not found: ID $product_id");
        }

        // ✅ Check quantity must be more than 0
        if ($quantity <= 0) {
            throw new Exception("Invalid quantity for product ID $product_id");
        }

        // Ensure stock is enough
        if ($quantity > $product['in_stock']) {
            throw new Exception("Insufficient stock for product ID $product_id");
        }

        // Insert sales item
        $stmt = $pdo->prepare("INSERT INTO sale_items (sale_id, product_id, quantity, price, total) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$sale_id, $product_id, $quantity, $price, $total]);

        // Deduct stock
        $stmt = $pdo->prepare("UPDATE products SET in_stock = in_stock - ? WHERE product_id = ?");
        $stmt->execute([$quantity, $product_id]);
    }


    $pdo->commit();

    echo json_encode(['success' => true, 'sale_id' => $sale_id]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
