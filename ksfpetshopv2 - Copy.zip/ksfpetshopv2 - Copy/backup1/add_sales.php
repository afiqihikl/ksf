<?php
include 'db.php'; // Ensure database connection is established

// Set timezone to Malaysia (UTC+8)
date_default_timezone_set('Asia/Kuala_Lumpur');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
    $date = date('Y-m-d H:i:s'); // Store both date and time

    if ($product_id > 0 && $quantity > 0) {
        try {
            // Check if product exists and get the current stock
            $stmt = $pdo->prepare("SELECT in_stock FROM products WHERE product_id = ?");
            $stmt->execute([$product_id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($product && $product['in_stock'] >= $quantity) {
                // Insert into sales table
                $insert_stmt = $pdo->prepare("INSERT INTO sales (product_id, date, total_sales) VALUES (?, ?, ?)");
                $insert_stmt->execute([$product_id, $date, $quantity]);

                // Update the stock in the products table
                $update_stmt = $pdo->prepare("UPDATE products SET in_stock = in_stock - ? WHERE product_id = ?");
                $update_stmt->execute([$quantity, $product_id]);

                echo "<script>alert('Sale recorded successfully!'); window.location.href='sales.php';</script>";
            } else {
                echo "<script>alert('Insufficient stock!'); window.history.back();</script>";
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    } else {
        echo "<script>alert('Invalid product or quantity!'); window.history.back();</script>";
    }
}
?>
