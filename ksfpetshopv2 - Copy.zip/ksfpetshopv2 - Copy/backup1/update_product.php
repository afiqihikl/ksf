<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize input values
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $product_title = isset($_POST['product_title']) ? trim($_POST['product_title']) : '';
    $category_id = isset($_POST['category']) ? intval($_POST['category']) : 0;
    $vendor_id = isset($_POST['vendor_name']) ? intval($_POST['vendor_name']) : 0;
    $in_stock = isset($_POST['in_stock']) ? intval($_POST['in_stock']) : 0;
    $buying_price = isset($_POST['buying_price']) ? floatval($_POST['buying_price']) : 0.00;
    $selling_price = isset($_POST['selling_price']) ? floatval($_POST['selling_price']) : 0.00;

    // Check if all required fields are filled
    if ($product_id && $product_title && $category_id && $vendor_id && $in_stock >= 0 && $buying_price >= 0 && $selling_price >= 0) {
        try {
            // Prepare and execute update query
            $query = "UPDATE products 
                      SET product_title = :product_title, 
                          category_id = :category_id, 
                          vendor_id = :vendor_id, 
                          in_stock = :in_stock, 
                          buying_price = :buying_price, 
                          selling_price = :selling_price 
                      WHERE product_id = :product_id";

            $stmt = $pdo->prepare($query);
            $stmt->execute([
                ':product_title' => $product_title,
                ':category_id' => $category_id,
                ':vendor_id' => $vendor_id,
                ':in_stock' => $in_stock,
                ':buying_price' => $buying_price,
                ':selling_price' => $selling_price,
                ':product_id' => $product_id
            ]);

            // Redirect with success message
            header("Location: product.php?status=success");
            exit();
        } catch (PDOException $e) {
            // Redirect with error message
            header("Location: product.php?status=error&message=" . urlencode($e->getMessage()));
            exit();
        }
    } else {
        // Redirect with validation error
        header("Location: product.php?status=error&message=Invalid input data");
        exit();
    }
} else {
    // Redirect if accessed directly
    header("Location: product.php");
    exit();
}
?>
