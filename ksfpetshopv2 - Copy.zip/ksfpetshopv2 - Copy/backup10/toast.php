<?php if (isset($_SESSION['toast_message'])): ?>
    <div class="mt-5 position-fixed top-0 end-0 p-3" style="z-index: 11">
        <div id="myToast" class="toast text-white bg-<?= $_SESSION['toast_type'] ?? 'success' ?> border-0" role="alert" aria-live="assertive" aria-atomic="true">

            <div class="toast-header bg-transparent text-white border-0">
                <strong class="me-auto">Notification</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>

            <div class="toast-body">
                <?= htmlspecialchars($_SESSION['toast_message']) ?>
            </div>

        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var toastEl = document.getElementById('myToast');
            var toast = new bootstrap.Toast(toastEl, {
                delay: 5000, // 5000ms = 5 seconds
                //autohide: true // enable auto-hide
            });
            toast.show();
        });
    </script>
    <?php unset($_SESSION['toast_message'], $_SESSION['toast_type']); ?>
<?php endif; ?>