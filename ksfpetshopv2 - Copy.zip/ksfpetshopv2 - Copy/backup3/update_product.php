<?php
include 'db.php';
include 'toast.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize input values
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $product_title = isset($_POST['product_title']) ? trim($_POST['product_title']) : '';
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
    $vendor_id = isset($_POST['vendor_id']) ? intval($_POST['vendor_id']) : 0;
    $in_stock = isset($_POST['in_stock']) ? intval($_POST['in_stock']) : 0;
    $buying_price = isset($_POST['buying_price']) ? floatval($_POST['buying_price']) : 0.00;
    $selling_price = isset($_POST['selling_price']) ? floatval($_POST['selling_price']) : 0.00;

    // Check if all required fields are filled
    if ($product_id > 0 && !empty($product_title) && $category_id > 0 && $vendor_id > 0 && $buying_price >= 0 && $selling_price >= 0) {
        try {
            // Prepare and execute update query
            $query = "UPDATE products 
                      SET product_title = :product_title, 
                          category_id = :category_id, 
                          vendor_id = :vendor_id, 
                          in_stock = :in_stock, 
                          buying_price = :buying_price, 
                          selling_price = :selling_price 
                      WHERE product_id = :product_id";

            $stmt = $pdo->prepare($query);
            $stmt->execute([
                ':product_title' => $product_title,
                ':category_id' => $category_id,
                ':vendor_id' => $vendor_id,
                ':in_stock' => $in_stock,
                ':buying_price' => $buying_price,
                ':selling_price' => $selling_price,
                ':product_id' => $product_id
            ]);

            // Success message
            setToast('success', 'Product updated successfully!');
        } catch (PDOException $e) {
            // Error message
            setToast('danger', 'Error updating product: ' . $e->getMessage());
        }
    } else {
        // Validation error
        setToast('danger', 'Please fill in all required fields correctly.');
    }
}

// Redirect after processing
header("Location: product.php");
exit();
?>
