<?php
include 'db.php'; // this gives you $pdo

$low_stock_products = [];
$low_stock_count = 0;

$sql = "SELECT product_title, in_stock, product_code FROM products WHERE in_stock <= 10";
$stmt = $pdo->query($sql);

if ($stmt && $stmt->rowCount() > 0) {
    $low_stock_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $low_stock_count = count($low_stock_products);
}
?>
