<?php
include 'sidebar.php';
include 'db.php'; // Ensure database connection is included

// Fetch total stats and sales revenue in a single query where possible

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css"> <!-- Ensure CSS file is included -->
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">Dashboard</h1>
        <div class="row">
            <div class="col-6">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        testing
                    </div>
                    <div class="card-body">
                        testing
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        testing
                    </div>
                    <div class="card-body">
                        testing
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>