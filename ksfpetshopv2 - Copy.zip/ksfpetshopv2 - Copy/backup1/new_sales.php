<?php
include 'db.php'; // Ensure this path is correct
include 'sidebar.php';

// Check if a search term was submitted
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$query = "SELECT p.product_code, p.product_id, p.product_title, p.selling_price, p.in_stock, 
                 c.category_name, v.vendor_name 
          FROM products p
          JOIN category c ON p.category_id = c.category_id
          JOIN vendors v ON p.vendor_id = v.vendor_id";

$params = [];

if (!empty($search)) {
    $query .= " WHERE p.product_title LIKE :search OR p.product_code LIKE :search";
    $params[':search'] = "%$search%";
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">SALES</h1>

        <div class="row">
            <div class="col-12">
                <form action="" method="GET">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Search by title or product code" value="<?= htmlspecialchars($search) ?>">
                        <button class="btn btn-primary" type="submit">Search</button>
                    </div>
                </form>
                <div class="card mt-4" style="height:100%">
                    <div class="card-header">
                        ADD SALES
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>                                        
                                        <th>Product Title</th>
                                        <th>Product Code</th>
                                        <th>Category Name</th>
                                        <th>Vendor Name</th>
                                        <th>Selling Price</th>
                                        <th>Qty</th>
                                        <th>Total</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($products): ?>
                                        <?php foreach ($products as $product): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($product['product_title']) ?></td>
                                                <td><?= htmlspecialchars($product['product_code']) ?></td>
                                                <td><?= htmlspecialchars($product['category_name']) ?></td>
                                                <td><?= htmlspecialchars($product['vendor_name']) ?></td>
                                                <td class="selling-price"><?= htmlspecialchars($product['selling_price']) ?></td>
                                                <td>
                                                    <form action="add_sales.php" method="POST">
                                                        <input type="hidden" name="product_id" value="<?= $product['product_id'] ?>">
                                                        <input type="number" name="quantity" class="form-control qty-input" placeholder="Quantity" min="1" required>
                                                </td>
                                                <td class="total-price">0.00</td> <!-- This will be updated dynamically -->
                                                <td>
                                                    <button type="submit" class="btn btn-primary"><i class='fa fa-dollar'></i> Add Sale</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No products found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Select all quantity inputs
            const qtyInputs = document.querySelectorAll(".qty-input");

            qtyInputs.forEach(input => {
                input.addEventListener("input", function() {
                    let row = this.closest("tr"); // Find the closest row
                    let price = parseFloat(row.querySelector(".selling-price").textContent); // Get selling price
                    let qty = parseInt(this.value) || 0; // Get quantity (default to 0 if empty)
                    let total = price * qty; // Calculate total

                    row.querySelector(".total-price").textContent = total.toFixed(2); // Update total column
                });
            });
        });
    </script>

</body>

</html>


<!-- <script>
    document.addEventListener("DOMContentLoaded", function() {
        // Select all quantity inputs
        const qtyInputs = document.querySelectorAll(".qty-input");

        qtyInputs.forEach(input => {
            input.addEventListener("input", function() {
                let row = this.closest("tr"); // Find the closest row
                let price = parseFloat(row.querySelector(".selling-price").textContent); // Get selling price
                let qty = parseInt(this.value) || 0; // Get quantity (default to 0 if empty)
                let total = price * qty; // Calculate total

                row.querySelector(".total-price").textContent = total.toFixed(2); // Update total column
            });
        });
    });
</script> -->