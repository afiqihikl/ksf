<?php
session_start();
include 'db.php'; // your PDO connection


// Ensure user is authenticated
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

$user_id = $_SESSION['user_id'];
$company_name = "Pet Shop XYZ";

// Decode JSON body from fetch()
$rawData = file_get_contents("php://input");
$data = json_decode($rawData, true);
$cart_items = $data['cart'] ?? [];

if (empty($cart_items)) {
    echo json_encode(['success' => false, 'message' => 'Cart is empty']);
    exit;
}

try {
    // Start transaction
    $pdo->beginTransaction();

    // Step 1: Insert into sales
    $sale_date = date('Y-m-d H:i:s');
    $stmt = $pdo->prepare("INSERT INTO sales (sale_date) VALUES (:sale_date)");
    $stmt->execute(['sale_date' => $sale_date]);
    $sale_id = $pdo->lastInsertId();

    // Step 2: Insert sale items and calculate total
    $stmt = $pdo->prepare("INSERT INTO sale_items (sale_id, product_id, quantity, price, total) 
                           VALUES (:sale_id, :product_id, :quantity, :price, :total)");
    $total_amount = 0;

    foreach ($cart_items as $item) {
        $subtotal = $item['price'] * $item['quantity'];
        $total_amount += $subtotal;

        $stmt->execute([
            'sale_id' => $sale_id,
            'product_id' => $item['id'],
            'quantity' => $item['quantity'],
            'price' => $item['price'],
            'total' => $subtotal,
        ]);
    }

    // Step 3: Create invoice
    $invoice_number = uniqid("INV-");
    $stmt = $pdo->prepare("INSERT INTO invoices (invoice_number, invoice_date, company_name, user_id, total_amount)
                           VALUES (:invoice_number, :invoice_date, :company_name, :user_id, :total_amount)");
    $stmt->execute([
        'invoice_number' => $invoice_number,
        'invoice_date' => $sale_date,
        'company_name' => $company_name,
        'user_id' => $user_id,
        'total_amount' => $total_amount,
    ]);
    $invoice_id = $pdo->lastInsertId();

    // Step 4: Insert invoice items
    $stmt = $pdo->prepare("INSERT INTO invoice_items (invoice_id, product_id, quantity, price, total, product_code)
                           VALUES (:invoice_id, :product_id, :quantity, :price, :total, :product_code)");

    foreach ($cart_items as $item) {
        $subtotal = $item['price'] * $item['quantity'];
        $stmt->execute([
            'invoice_id' => $invoice_id,
            'product_id' => $item['id'],
            'quantity' => $item['quantity'],
            'price' => $item['price'],
            'total' => $subtotal,
            'product_code' => $item['code'] ?? 'N/A',
        ]);
    }

    // Commit and return success
    $pdo->commit();

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Transaction failed: ' . $e->getMessage()]);
}
?>
