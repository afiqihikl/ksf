<?php
include 'db.php';
include 'toast.php';

if (isset($_GET['id'])) {
    $category_id = $_GET['id'];

    try {
        // Delete category from database
        $stmt = $pdo->prepare("DELETE FROM category WHERE category_id = :category_id");
        $stmt->execute([':category_id' => $category_id]);

        setToast('success', 'Category deleted successfully!');
    } catch (PDOException $e) {
        setToast('danger', 'Error deleting category: ' . $e->getMessage());
    }
} else {
    setToast('danger', 'Invalid category ID.');
}

// Redirect to category.php
header("Location: category.php");
exit;
?>
