<?php
include 'db.php';
include 'sidebar.php';

$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize the category name
    $category_name = htmlspecialchars($_POST['category'] ?? '');

    if (!empty($category_name)) {
        try {
            // Prepare an SQL statement to insert the category
            $stmt = $pdo->prepare("INSERT INTO category (category_name) VALUES (:category_name)");
            $stmt->execute([':category_name' => $category_name]);
            $success = "Category added successfully!";
        } catch (PDOException $e) {
            // Handle database errors
            $error = "Error adding category: " . $e->getMessage();
        }
    } else {
        $error = "Category name cannot be empty.";
    }
}

$query = "SELECT * FROM category";
$stmt = $pdo->query($query);
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <!-- Bootstrap Toast Container (Fixed Position) -->
    <div class="toast-container">
        <div id="toastMessage" class="toast" data-delay="3000">
            <div class="toast-header">
                <strong class="mr-auto text-success">Notification</strong>
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast">&times;</button>
            </div>
            <div class="toast-body">
                <?= $success ?: $error ?>
            </div>
        </div>
    </div>

    <div class="content" id="content">
        <h1 class="mt-4">Category</h1>
        <div class="row">
            <div class="col-6">
                <div class="card" style="height:100%">
                    <div class="card-header">ADD NEW CATEGORY</div>
                    <div class="card-body">
                        <form action="category.php" method="POST">
                            <div class="form-group">
                                <label for="category_name">Category Name:</label>
                                <input type="text" class="form-control" placeholder="Enter Category Name" id="category" name="category">
                            </div>
                            <button type="submit" class="btn btn-primary" style="width:100%">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="card" style="height:100%">
                    <div class="card-header">ALL CATEGORY</div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Category</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($categories as $index => $category) : ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td><?= htmlspecialchars($category['category_name']) ?></td>
                                            <td>
                                                <button type="button" class="btn btn-secondary btn-sm edit-btn"
                                                    data-toggle="modal"
                                                    data-target="#editModal"
                                                    data-id="<?= $category['category_id'] ?>"
                                                    data-name="<?= $category['category_name'] ?>"><i class="fa fa-edit"></i>
                                                    Edit
                                                </button>
                                                <a href="delete_category.php?id=<?= $category['category_id'] ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i> Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Edit Category</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="modal-body">
                    <form action="update_category.php" method="POST">
                        <input type="hidden" id="editCategoryId" name="category_id">
                        <div class="form-group">
                            <label for="editCategoryName">Category Name</label>
                            <input type="text" class="form-control" id="editCategoryName" name="category_name" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Change</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            <?php if (!empty($success) || !empty($error)) : ?>
                $("#toastMessage").toast("show");
            <?php endif; ?>
        });
    </script>
</body>

</html>