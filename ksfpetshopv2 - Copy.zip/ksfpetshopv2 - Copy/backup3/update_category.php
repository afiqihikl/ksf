<?php
include 'db.php';
include 'toast.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_id = $_POST['category_id'] ?? null;
    $category_name = htmlspecialchars($_POST['category_name'] ?? '');

    if ($category_id && !empty($category_name)) {
        try {
            $stmt = $pdo->prepare("UPDATE category SET category_name = :category_name WHERE category_id = :category_id");
            $stmt->execute([
                ':category_name' => $category_name,
                ':category_id' => $category_id
            ]);

            setToast('success', 'Category updated successfully!');
        } catch (PDOException $e) {
            setToast('danger', 'Error updating category: ' . $e->getMessage());
        }
    } else {
        setToast('danger', 'Category name cannot be empty.');
    }
}

header("Location: category.php");
exit;
?>
