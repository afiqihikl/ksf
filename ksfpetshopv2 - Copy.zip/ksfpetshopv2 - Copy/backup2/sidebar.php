<?php
session_start();
$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <!-- <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> -->
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #262626;
            padding: 10px 20px;
            color: white;
            position: fixed;
            /* Fixed position */
            top: 0;
            left: 0;
            width: 100%;
            /* Stretches across the width of the viewport */
            z-index: 1000;
            /* Ensures it appears above other elements */
        }

        .nav-left {
            display: flex;
            align-items: center;
            gap: 15px;
            /* Adjust spacing between icon and logo */
        }

        .logo {
            font-size: 20px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }

        .navbar .icon {
            font-size: 24px;
            font-weight: bold;
            cursor: pointer;
        }

        .navbar .links {
            display: flex;
            gap: 0px;
            margin-right: 30px;
        }

        .navbar .links a {
            text-decoration: none;
            color: white;
            padding: 5px 10px;
            transition: background-color 0.3s;
        }

        .navbar .links a:hover {
            background-color: #4d4d4d;
            border-radius: 5px;
        }

        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: #262626;
            color: white;
            position: fixed;
            /* Fixed position */
            top: 56px;
            /* Space below the fixed navbar */
            left: 0;
            display: flex;
            flex-direction: column;
            padding: 0px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .sidebar.collapsed {
            transform: translateX(-240px);
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            margin: 0px 0px;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #4d4d4d;
        }

        .content {
            margin-left: 200px;
            padding: 50px 20px;
            /* Adds space below navbar */
            transition: margin-left 0.3s ease;
        }

        .content.collapsed {
            margin-left: 0;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                /* Sidebar adjusts on small screens */
            }

            .content {
                margin-left: 0;
            }

            .navbar {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>

<body>
    <div class="navbar">
        <div class="nav-left">
            <div class="icon" onclick="toggleSidebar()"><i class="fa fa-bars"></i></div>
            <a href="index.php" class="logo"> KSF PETSHOP </a>
        </div>
        <div class="links">
            <!-- <a href="#">Home</a>
            <a href="#">Products</a> -->
            <a href="cart.php" style="position: relative;">
                <i class="fa fa-shopping-cart"></i>
                <?php if ($cart_count > 0): ?>
                    <span id="cart-count" style="
                    position: absolute;
                    top: 1px;
                    right: -1px;
                    background: red;
                    color: white;
                    font-size: 10px;
                    font-weight: bold;
                    border-radius: 50%;
                    padding: 1px 5px;
                ">
                        <?= $cart_count ?>
                    </span>
                <?php endif; ?>
            </a>
        </div>
    </div>

    <div class="sidebar" id="sidebar">
        <a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a>
        <a href="category.php"><i class="fa fa-list-alt"></i> Category</a>
        <a href="vendor.php"><i class='fa fa-truck'></i> Supplier</a>
        <a href="product.php"><i class='fa fa-archive'></i> Product</a>
        <a href="sales.php"><i class='fa fa-dollar'></i> Sales</a>
    </div>
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const content = document.getElementById('content');
            sidebar.classList.toggle('collapsed');
            content.classList.toggle('collapsed');
        }
    </script>
</body>

</html>