<?php
include 'sidebar.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">PRODUCT</h1>
        <div class="card mt-4">
            <div class="card-header">
                Edit Product
            </div>
            <div class="card-body">
                <form>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Product Title" id="title" name="title">
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <select class="form-control" placeholder="Select Category" id="sel1" name="category">
                                    <option value="" disabled selected>Select Category</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                </select>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="customFile">
                                    <label class="custom-file-label" for="customFile">Choose file</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <input type="number" class="form-control" placeholder="Product Quantity" id="in_stock">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <input type="number" class="form-control" placeholder="Buying Price" id="buying_price">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <input type="number" class="form-control" placeholder="Quantity Price" id="selling_price">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
            <div class="card-footer">

            </div>
        </div>
    </div>
</body>

</html>