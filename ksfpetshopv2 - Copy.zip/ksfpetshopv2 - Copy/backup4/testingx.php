<?php
include 'sidebar.php';
include 'db.php'; // Ensure database connection is included

// Fetch products with category and vendor details
$query = "SELECT 
            p.product_id, 
            p.photos, 
            p.product_title, 
            c.category_name, 
            v.vendor_name, 
            v.vendor_address, 
            p.in_stock, 
            p.buying_price, 
            p.selling_price,
            p.product_code 
          FROM products p
          JOIN category c ON p.category_id = c.category_id
          JOIN vendors v ON p.vendor_id = v.vendor_id";

$products = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
// Fetch categories from the database
$categories = $pdo->query("SELECT * FROM category")->fetchAll(PDO::FETCH_ASSOC);
// Fetch vendors from the database
$vendors = $pdo->query("SELECT * FROM vendors")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css"> <!-- Ensure CSS file is included -->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.css" />
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">Point of Sale</h1>
        <div class="row mt-4">
            <div class="col-7">
                <div class="card" style="height:100%;">
                    <div style="background-color:rgb(0, 25, 67);" class="card-header text-white">
                        <form action="/action_page.php">
                            <div class="input-group">
                                <span class="input-group-text bg-white"><i class="fa fa-search text-muted"></i></span>
                                <input type="text" class="form-control" placeholder="Search Barcode" aria-label="Search Barcode">
                            </div>
                        </form>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table id="ksfTable1" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Photo</th>
                                        <th>Product Title</th>
                                        <th>Product Code</th>
                                        <th>In Stock</th>
                                        <th>Sell Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody style="font-size:14px;">
                                    <?php if (!empty($products)): ?>
                                        <?php foreach ($products as $index => $product): ?>
                                            <tr>
                                                <td><?= $index + 1 ?></td>
                                                <td>
                                                    <?php if (!empty($product['photos'])): ?>
                                                        <img src="<?= htmlspecialchars($product['photos']) ?>" alt="Product Image" width="50">
                                                    <?php else: ?>
                                                        No Image
                                                    <?php endif; ?>
                                                </td>
                                                <td><?= htmlspecialchars($product['product_title']) ?></td>
                                                <td><?= htmlspecialchars($product['product_code']) ?></td>
                                                <td><?= $product['in_stock'] ?></td>
                                                <td>RM<?= number_format($product['selling_price'], 2) ?></td>
                                                <td style="width:156px;">
                                                    <button type="button" class="btn btn-primary"><i class="fa fa-shopping-cart"></i></button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No products found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-5">
                <div class="card" style="height:620px;">
                    <div style="font-size:26px;" class="card-header text-black text-center bg-white">Cart</div>
                    <div class="card-body bg-white" style="height: 300px; overflow-y: auto;" id="cart-items">
                        <div id="cart-items" style="max-height: 350px; overflow-y: auto;"></div>

                        <div class="text-right mt-2">
                            <button class="btn btn-outline-danger btn-sm" onclick="clearCart()">
                                <i class="fa fa-trash"></i> Clear Cart
                            </button>
                        </div>

                        <div id="cart-total" class="mt-3"></div>

                    </div>
                    <div class="card-body bg-white" id="cart-total">
                        <h5 class="text-right">Total: <strong>RM0.00</strong></h5>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
    <script>
        let cart = [];

        const cartContainer = document.getElementById('cart-items');
        const totalContainer = document.getElementById('cart-total');

        function saveCart() {
            localStorage.setItem('ksf_cart', JSON.stringify(cart));
        }

        function loadCart() {
            const storedCart = localStorage.getItem('ksf_cart');
            if (storedCart) {
                cart = JSON.parse(storedCart);
            }
        }

        function updateCartUI() {
            cartContainer.innerHTML = '';
            let total = 0;

            if (cart.length === 0) {
                cartContainer.innerHTML = '<p class="text-center text-muted">Cart is empty</p>';
            } else {
                cart.forEach((item, index) => {
                    const subtotal = item.price * item.quantity;
                    total += subtotal;

                    const row = document.createElement('div');
                    row.classList.add('d-flex', 'justify-content-between', 'align-items-center', 'border-bottom', 'py-2');
                    row.innerHTML = `
                    <div>
                        <strong>${item.title}</strong><br>
                        <div class="input-group input-group-sm mt-1">
                            <button class="btn btn-outline-secondary" onclick="changeQuantity(${index}, -1)" ${item.quantity <= 1 ? 'disabled' : ''}>-</button>
                            <input type="text" class="form-control text-center mx-1" style="width: 40px;" value="${item.quantity}" readonly>
                            <button class="btn btn-outline-secondary" onclick="changeQuantity(${index}, 1)" ${item.quantity >= item.stock ? 'disabled' : ''}>+</button>
                        </div>
                    </div>
                    <div>
                        RM${subtotal.toFixed(2)}
                        <button class="btn btn-sm btn-danger ml-2" onclick="removeItem(${index})">
                            <i class="fa fa-trash"></i>
                        </button>
                    </div>
                `;
                    cartContainer.appendChild(row);
                });

                // Clear Cart Button
                const clearBtn = document.createElement('div');
                clearBtn.classList.add('text-right', 'mt-2');
                clearBtn.innerHTML = `
                <button class="btn btn-outline-danger btn-sm" onclick="clearCart()">
                    <i class="fa fa-trash"></i> Clear Cart
                </button>
            `;
                cartContainer.appendChild(clearBtn);
            }

            totalContainer.innerHTML = `
            <h5 class="text-right">Total: <strong>RM${total.toFixed(2)}</strong></h5>
        `;

            saveCart();
        }

        function addToCart(id, title, price, maxStock) {
            const existing = cart.find(item => item.id === id);
            if (existing) {
                if (existing.quantity >= maxStock) {
                    alert("You've reached the maximum stock available for this product.");
                    return;
                }
                existing.quantity++;
            } else {
                cart.push({
                    id,
                    title,
                    price,
                    quantity: 1,
                    stock: maxStock
                });
            }
            updateCartUI();
        }

        function removeItem(index) {
            cart.splice(index, 1);
            updateCartUI();
        }

        function clearCart() {
            if (confirm('Clear all items from the cart?')) {
                cart = [];
                updateCartUI();
            }
        }

        function changeQuantity(index, change) {
            const item = cart[index];
            const newQty = item.quantity + change;

            if (newQty >= 1 && newQty <= item.stock) {
                item.quantity = newQty;
                updateCartUI();
            }
        }

        // Load cart on page load
        loadCart();
        updateCartUI();

        // Attach Add to Cart buttons with stock check
        document.querySelectorAll('.btn-primary').forEach(button => {
            button.addEventListener('click', function() {
                const row = this.closest('tr');
                const id = row.children[0].textContent.trim();
                const title = row.children[2].textContent.trim();
                const price = parseFloat(row.children[5].textContent.replace('RM', ''));
                const stock = parseInt(row.children[4].textContent);

                addToCart(id, title, price, stock);
            });
        });
    </script>
</body>

</html>