<?php
include 'sidebar.php';
include 'db.php'; // Ensure database connection is included

// Fetch total stats and sales revenue in a single query where possible
$statsQuery = "
    SELECT 
        (SELECT SUM(in_stock) FROM products) AS total_inventory,
        (SELECT COUNT(product_id) FROM products) AS total_products,
        (SELECT COUNT(category_id) FROM category) AS total_categories,
        (SELECT SUM(s.total_sales * p.selling_price) 
         FROM sales s 
         JOIN products p ON s.product_id = p.product_id) AS total_revenue
";

$stats = $pdo->query($statsQuery)->fetch(PDO::FETCH_ASSOC) ?? ['total_inventory' => 0, 'total_products' => 0, 'total_categories' => 0, 'total_revenue' => 0];

// Fetch highest selling products
$topSellingQuery = "
    SELECT p.product_title, SUM(s.total_sales) AS total_sold
    FROM sales s
    JOIN products p ON s.product_id = p.product_id
    GROUP BY s.product_id
    ORDER BY total_sold DESC
    LIMIT 10";
$topSellingProducts = $pdo->query($topSellingQuery)->fetchAll(PDO::FETCH_ASSOC);

// Fetch latest sales
$salesQuery = "
    SELECT s.sales_id, p.product_title, s.total_sales AS quantity, 
           (s.total_sales * p.selling_price) AS total_price, s.date 
    FROM sales s
    JOIN products p ON s.product_id = p.product_id
    ORDER BY s.date DESC";
$sales = $pdo->query($salesQuery)->fetchAll(PDO::FETCH_ASSOC);

// Fetch products along with their categories and vendors
$productQuery = "
    SELECT p.product_id, p.photos, p.product_title, c.category_name, v.vendor_name, 
           p.in_stock, p.buying_price, p.selling_price, p.product_added_time, p.product_code 
    FROM products p
    JOIN category c ON p.category_id = c.category_id
    JOIN vendors v ON p.vendor_id = v.vendor_id";
$products = $pdo->query($productQuery)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css"> <!-- Ensure CSS file is included -->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.css" />
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">Dashboard</h1>
        <div class="row">
            <div class="col-3">
                <div style="background-color:rgb(0, 25, 67);" class="card text-white">
                    <div class="card-header text-center">Total Inventory</div>
                    <div class="card-body text-center">
                        <h2><?= number_format($stats['total_inventory']) ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <div style="background-color:rgb(0, 25, 67);" class="card text-white">
                    <div class="card-header text-center">Total Sales Revenue</div>
                    <div class="card-body text-center">
                        <h2><?= number_format($stats['total_revenue'], 2) ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <div style="background-color:rgb(0, 25, 67);" class="card text-white">
                    <div class="card-header text-center">Total Products</div>
                    <div class="card-body text-center">
                        <h2><?= number_format($stats['total_products']) ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <div style="background-color:rgb(0, 25, 67);" class="card text-white">
                    <div class="card-header text-center">Total Categories</div>
                    <div class="card-body text-center">
                        <h2><?= number_format($stats['total_categories']) ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-4">
                <div class="card" style="height:100%;">
                    <div style="background-color:rgb(0, 25, 67);" class="card-header text-white text-center">Highest Selling Product</div>
                    <div class="card-body">
                        <div class="table-responsive-sm text-center" style="font-size: 85%;">
                            <table id="ksfTable1" class=" table table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Product Title</th>
                                        <th>Total Sold</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($topSellingProducts as $index => $product): ?>
                                        <tr>
                                            <td><?= $index + 1; ?></td>
                                            <td><?= htmlspecialchars($product['product_title']); ?></td>
                                            <td><?= $product['total_sold']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($topSellingProducts)): ?>
                                        <tr>
                                            <td colspan="3" class="text-center">No sales data available</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-4">
                <div class="card" style="height:100%;">
                    <div style="background-color:rgb(0, 25, 67);" class="card-header text-white text-center">Latest Product Sold</div>
                    <div class="card-body">
                        <div class="table-responsive-sm text-center" style="font-size: 85%;">
                            <table id="ksfTable2" class=" table table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Product Title</th>
                                        <th>Date and Time</th>
                                        <th>Total Sale</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($sales as $index => $sale): ?>
                                        <tr>
                                            <td><?= $index + 1; ?></td>
                                            <td><?= htmlspecialchars($sale['product_title']); ?></td>
                                            <td><?= htmlspecialchars($sale['date']); ?></td>
                                            <td><?= number_format($sale['total_price'], 2); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($sales)): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">No sales recorded</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-4">
                <div class="card" style="height:100%;">
                    <div style="background-color:rgb(0, 25, 67);" class="card-header text-white text-center">Recently Added Products</div>
                    <div class="card-body">
                        <div class="table-responsive-sm text-center" style="font-size: 85%;">
                            <table id="ksfTable3" class=" table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Product Title</th>
                                        <th>Category</th>
                                        <th>Vendor</th>
                                        <th>Time Added</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($products as $product): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($product['product_title']) ?></td>
                                            <td><?= htmlspecialchars($product['category_name']) ?></td>
                                            <td><?= htmlspecialchars($product['vendor_name']) ?></td>
                                            <td><?= htmlspecialchars($product['product_added_time']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($products)): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">No products found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>

</html>