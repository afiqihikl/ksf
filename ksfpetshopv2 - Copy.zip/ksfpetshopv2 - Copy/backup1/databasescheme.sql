-- Create Roles table
CREATE TABLE roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(255) NOT NULL
);

-- Create Users table
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

-- Create Category table
CREATE TABLE category (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(255) NOT NULL
);

-- Create Vendors table
CREATE TABLE vendors (
    vendor_id INT AUTO_INCREMENT PRIMARY KEY,
    vendor_name VARCHAR(255) NOT NULL,
    vendor_status VARCHAR(50) NOT NULL,
    vendor_contact VARCHAR(50) NOT NULL,
    vendor_address TEXT NOT NULL,
    vendor_personincharge VARCHAR(255) NOT NULL
);

-- Create Products table
CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    photos TEXT,
    product_title VARCHAR(255) NOT NULL,
    category_id INT NOT NULL,
    vendor_id INT NOT NULL,
    in_stock INT NOT NULL,
    buying_price DECIMAL(10, 2) NOT NULL,
    selling_price DECIMAL(10, 2) NOT NULL,
    product_added_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    product_code CHAR(8) NOT NULL ;
    FOREIGN KEY (category_id) REFERENCES category(category_id),
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);

-- Create Sales table
CREATE TABLE sales (
    sales_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
    total_sales INT NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);
