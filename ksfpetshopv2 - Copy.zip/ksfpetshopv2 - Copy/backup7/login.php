<?php
include 'db.php';
session_start();

// Check if the user is already logged in
if (isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

// Check if the form is submitted
$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = htmlspecialchars($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Fetch the user from the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = $user['username'];
        $_SESSION['role_id'] = $user['role_id'];
        $_SESSION['toast_message'] = "Login successful! Welcome, " . $user['username'] . "!";
        $_SESSION['toast_type'] = "success";
        header("Location: index.php");
        exit;
    } else {
        $_SESSION['toast_message'] = "Invalid username or password.";
        $_SESSION['toast_type'] = "danger";
        header("Location: login.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, rgb(232, 226, 238), rgb(116, 131, 157));
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            font-family: Arial, sans-serif;
            color: white;
        }

        .login-container {
            background: rgb(0, 25, 67);
            border-radius: 10px;
            padding: 20px 30px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }

        .login-container h2 {
            margin-bottom: 20px;
            color: white;
            text-align: center;
        }

        .form-control {
            background-color: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
        }

        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.3);
            box-shadow: none;
            border: none;
        }

        /* .btn-primary {
            background-color: #6a11cb;
            border: none;
        }
        .btn-primary:hover {
            background-color: #2575fc;
        } */
        .error-message {
            color: #f8d7da;
            background-color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h2 style="color:  rgb(199, 156, 2);">KSF Pet Shop</h2>
        <h3 style="color:  rgb(199, 156, 2); text-align: center;">Login</h3>
        <?php
        if (!empty($error)) {
            $_SESSION['toast_message'] = $error;
            $_SESSION['toast_type'] = 'danger'; // kita guna ni untuk tukar warna
        }
        ?>
        <form method="POST" action="login.php">
            <div class="mb-3">
                <label for="username" style="color:  rgb(199, 156, 2);" class="form-label">Username</label>
                <input type="text" style="color:  white;" class="form-control" id="username" name="username" placeholder="Enter your username" required>
            </div>
            <div class="mb-3">
                <label for="password" style="color:  rgb(199, 156, 2);" class="form-label">Password</label>
                <input type="password" style="color:  white;" class="form-control" id="password" name="password" placeholder="Enter your password" required>
            </div>
            <button type="submit" style="background-color:  rgb(199, 156, 2);" class="btn w-100">Login</button>
            <div class="mb-3 text-center">
                Don't have an account? <a href="register.php" class="text-decoration-none">Register here</a>
            </div>
        </form>
    </div>
    <?php if (!empty($error)) : ?>
        <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
            <div id="myToast" class="toast align-items-center text-white bg-danger border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        <?= htmlspecialchars($error) ?>
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>
        </div>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                var toastEl = document.getElementById('myToast');
                var toast = new bootstrap.Toast(toastEl);
                toast.show();
            });
        </script>
    <?php endif; ?>

</body>

</html>