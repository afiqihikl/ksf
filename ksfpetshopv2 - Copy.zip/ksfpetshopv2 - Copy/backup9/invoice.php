<?php
include 'db.php';
include 'sidebar.php';
include 'toast.php';

// Join invoice_items with invoices, users, and products
$stmt = $pdo->prepare("
    SELECT 
        ii.*, 
        i.invoice_number, 
        i.invoice_date, 
        u.full_name AS cashier_name, 
        p.product_title 
    FROM invoice_items ii
    JOIN invoices i ON ii.invoice_id = i.invoice_id
    JOIN users u ON i.user_id = u.user_id
    JOIN products p ON ii.product_id = p.product_id
");
$stmt->execute();
$invoiceItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice Details</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.css" />
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">All Invoice Items</h1>
        <div class="row">
            <div class="col-12">
                <div class="card" style="height:100%">
                    <div class="card-header">
                        Items
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table id="ksfTable1" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Invoice Number</th>
                                        <th>Invoice Date</th>
                                        <th>Cashier</th>
                                        <th>Product Title</th>
                                        <th>Quantity</th>
                                        <th>Total (RM)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($invoiceItems as $index => $item): ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td><?= htmlspecialchars($item['invoice_number']) ?></td>
                                            <td><?= htmlspecialchars(date('Y-m-d H:i', strtotime($item['invoice_date']))) ?></td>
                                            <td><?= htmlspecialchars($item['cashier_name']) ?></td>
                                            <td><?= htmlspecialchars($item['product_title']) ?></td>
                                            <td><?= htmlspecialchars($item['quantity']) ?></td>
                                            <td>RM<?= number_format($item['total'], 2) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>

</html>