<?php
include 'db.php'; // Ensure this contains a PDO connection ($pdo)

if (isset($_POST['product_code'])) {
    $product_code = $_POST['product_code'];

    try {
        // Check if product exists
        $query = "SELECT * FROM products WHERE product_code = :product_code";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':product_code', $product_code, PDO::PARAM_STR);
        $stmt->execute();
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($product) {
            // Update stock count
            $updateQuery = "UPDATE products SET in_stock = in_stock + 1 WHERE product_code = :product_code";
            $stmt = $pdo->prepare($updateQuery);
            $stmt->bindParam(':product_code', $product_code, PDO::PARAM_STR);
            
            if ($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Stock updated successfully!"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Failed to update stock!"]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Product not found!"]);
        }
    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => "Error: " . $e->getMessage()]);
    }
    exit; // Stop further execution to avoid HTML output
}

include 'sidebar.php'; // Include after AJAX logic
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- Add jQuery -->
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">PRODUCT</h1>

        <div class="row">
            <div class="col-12">
                <div class="card" style="height:100%">
                    <div class="card-header">
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-primary mr-2" onclick="window.location='new_product.php'"><i class='fa fa-plus-circle'></i> New Product</button>
                            <button type="button" class="btn btn-secondary mr-2" onclick="window.location='stock-in.php'"><i class='fa fa-plus-circle'></i> Stock In</button>
                            <button type="button" class="btn btn-secondary mr-2" onclick="window.location='stock-out.php'"><i class='fa fa-plus-circle'></i> Stock Out</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table class="table table-bordered">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="stock_in">Stock In:</label>
                                            <input type="text" class="form-control" placeholder="Enter Product Code Here" id="stock_in" maxlength="8">
                                        </div>
                                        <div id="responseMessage"></div> <!-- Message display area -->
                                    </div>
                                </div>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let typingTimer;
        const typingDelay = 0; // 500ms delay after typing stops

        $(document).ready(function () {
            $("#stock_in").on("input", function () {
                clearTimeout(typingTimer); // Clear previous timer
                let productCode = $(this).val();

                if (productCode.length === 8) { // Auto-submit when 8 characters are entered
                    typingTimer = setTimeout(checkStockIn, typingDelay);
                }
            });
        });

        function checkStockIn() {
            let productCode = $("#stock_in").val();
            if (productCode.length === 8) { 
                $.ajax({
                    url: "", // Same page
                    type: "POST",
                    data: { product_code: productCode },
                    dataType: "json",
                    success: function (response) {
                        let messageBox = $("#responseMessage");
                        messageBox.html(`<div class='alert alert-${response.status === "success" ? "success" : "danger"}'>${response.message}</div>`);
                        $("#stock_in").val(""); // Clear input field

                        // Hide message after 3 seconds
                        setTimeout(() => {
                            messageBox.html("");
                        }, 3000);
                    }
                });
            }
        }
    </script>
</body>

</html>
