<?php
session_start();
include 'db.php';
include 'toast.php'; // ✅ Include toast functions

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // ✅ Sanitize & Validate Input
        $vendor_id = filter_var($_POST['vendor_id'], FILTER_SANITIZE_NUMBER_INT);
        $vendor_name = trim(filter_var($_POST['vendor_name'], FILTER_SANITIZE_STRING));
        $vendor_status = trim($_POST['vendor_status']);
        $vendor_contact = trim(filter_var($_POST['vendor_contact'], FILTER_SANITIZE_STRING));
        $vendor_address = trim(filter_var($_POST['vendor_address'], FILTER_SANITIZE_STRING));
        $vendor_personincharge = trim(filter_var($_POST['vendor_personincharge'], FILTER_SANITIZE_STRING));

        // ✅ Check for empty fields
        if (empty($vendor_name) || empty($vendor_status) || empty($vendor_contact) || empty($vendor_address) || empty($vendor_personincharge)) {
            setToast('warning', 'All fields are required!');
            header("Location: vendor.php");
            exit();
        }

        // ✅ Update vendor details
        $sql = "UPDATE vendors 
                SET vendor_name = :vendor_name, 
                    vendor_status = :vendor_status, 
                    vendor_contact = :vendor_contact, 
                    vendor_address = :vendor_address, 
                    vendor_personincharge = :vendor_personincharge 
                WHERE vendor_id = :vendor_id";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':vendor_id' => $vendor_id,
            ':vendor_name' => $vendor_name,
            ':vendor_status' => $vendor_status,
            ':vendor_contact' => $vendor_contact,
            ':vendor_address' => $vendor_address,
            ':vendor_personincharge' => $vendor_personincharge
        ]);

        // ✅ Success Message (Using Toast)
        setToast('success', 'Vendor updated successfully!');
    } catch (PDOException $e) {
        // ✅ Error Message
        setToast('danger', 'Error updating vendor: ' . $e->getMessage());
    }

    header("Location: vendor.php");
    exit();
} else {
    header("Location: vendor.php");
    exit();
}
?>
