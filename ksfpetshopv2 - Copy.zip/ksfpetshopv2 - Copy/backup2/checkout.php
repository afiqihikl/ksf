<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['quantities'])) {
    foreach ($_POST['quantities'] as $id => $quantity) {
        if (isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id]['quantity'] = (int)$quantity;
        }
    }
}

$cart = $_SESSION['cart'];

try {
    $pdo->beginTransaction();

    foreach ($cart as $id => $item) {
        $query = $pdo->prepare("SELECT in_stock FROM products WHERE product_id = ?");
        $query->execute([$id]);
        $product = $query->fetch(PDO::FETCH_ASSOC);

        if (!$product) {
            throw new Exception("Product not found.");
        }

        $stock = $product['in_stock'];
        $quantity = $item['quantity'];

        if ($quantity > $stock) {
            throw new Exception("Not enough stock for product: " . htmlspecialchars($item['product_title']));
        }

        // Deduct stock
        $newStock = $stock - $quantity;
        $updateStock = $pdo->prepare("UPDATE products SET in_stock = ? WHERE product_id = ?");
        $updateStock->execute([$newStock, $id]);

        // Record sale
        $insertSale = $pdo->prepare("INSERT INTO sales (product_id, total_sales) VALUES (?, ?)");
        $insertSale->execute([$id, $quantity]);
    }

    $pdo->commit();

    // Clear cart
    unset($_SESSION['cart']);

    echo "<script>alert('Checkout successful!'); window.location.href='new_sales.php';</script>";
    exit();
} catch (Exception $e) {
    $pdo->rollBack();
    echo "<script>alert('Checkout failed: " . $e->getMessage() . "'); window.location.href='cart.php';</script>";
    exit();
}
?>
