<?php
ob_start();
include 'db.php';
include 'sidebar.php';
include 'modal.php';
include 'toast.php';

// Fetch products with category and vendor details
$query = "SELECT 
            p.product_id, 
            p.photos, 
            p.product_title, 
            c.category_name, 
            v.vendor_name, 
            v.vendor_address, 
            p.in_stock, 
            p.buying_price, 
            p.selling_price,
            p.product_code 
          FROM products p
          JOIN category c ON p.category_id = c.category_id
          JOIN vendors v ON p.vendor_id = v.vendor_id";

$products = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
// Fetch categories from the database
$categories = $pdo->query("SELECT * FROM category")->fetchAll(PDO::FETCH_ASSOC);
// Fetch vendors from the database
$vendors = $pdo->query("SELECT * FROM vendors")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.css" />
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
</head>

<body>
    <?php displayToast(); ?>
    <div class="content" id="content">
        <h1 class="mt-4">PRODUCT</h1>

        <div class="row">
            <div class="col-12">
                <div class="card" style="height:100%">
                    <div class="card-header">
                        <div class="d-flex justify-content-end ">
                            <button type="button" class="btn btn-primary mr-2" onclick="window.location='new_product.php'"><i class='fa fa-plus-circle'></i> New Product</button>
                            <button type="button" class="btn btn-secondary mr-2" onclick="window.location='stock-in.php'"><i class='fa fa-plus-circle'></i> stock in</button>
                            <button type="button" class="btn btn-secondary mr-2" onclick="window.location='stock-out.php'"><i class='fa fa-plus-circle'></i> stock out</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table id="ksfTable1" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Photo</th>
                                        <th>Product Title</th>
                                        <th>Product Code</th>
                                        <th>Category</th>
                                        <th>Vendor Name</th>
                                        <th>Vendor Address</th>
                                        <th>In Stock</th>
                                        <th>Buy Price</th>
                                        <th>Sell Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody style="font-size:14px;">
                                    <?php if (!empty($products)): ?>
                                        <?php foreach ($products as $index => $product): ?>
                                            <tr>
                                                <td><?= $index + 1 ?></td>
                                                <td>
                                                    <?php if (!empty($product['photos'])): ?>
                                                        <img src="<?= htmlspecialchars($product['photos']) ?>" alt="Product Image" width="50">
                                                    <?php else: ?>
                                                        No Image
                                                    <?php endif; ?>
                                                </td>
                                                <td><?= htmlspecialchars($product['product_title']) ?></td>
                                                <td><?= htmlspecialchars($product['product_code']) ?></td>
                                                <td><?= htmlspecialchars($product['category_name']) ?></td>
                                                <td><?= htmlspecialchars($product['vendor_name']) ?></td>
                                                <td><?= htmlspecialchars($product['vendor_address']) ?></td>
                                                <td><?= $product['in_stock'] ?></td>
                                                <td>RM<?= number_format($product['buying_price'], 2) ?></td>
                                                <td>RM<?= number_format($product['selling_price'], 2) ?></td>
                                                <td style="width:156px;">
                                                    <button type="button" class="btn btn-secondary btn-sm open-modal"
                                                        data-toggle="modal"
                                                        data-target="#universalModal"
                                                        data-type="edit"
                                                        data-id="<?= $product['product_id'] ?>"
                                                        data-title="<?= htmlspecialchars($product['product_title']) ?>"
                                                        data-category="<?= htmlspecialchars($product['category_name']) ?>"
                                                        data-vendor="<?= htmlspecialchars($product['vendor_name']) ?>"
                                                        data-stock="<?= $product['in_stock'] ?>"
                                                        data-buy="<?= $product['buying_price'] ?>"
                                                        data-sell="<?= $product['selling_price'] ?>"><i class="fa fa-edit"> </i>
                                                    </button>
                                                    <button type="button" class="btn btn-danger btn-sm open-modal"
                                                        data-toggle="modal"
                                                        data-target="#universalModal"
                                                        data-type="delete"
                                                        data-id="<?= $product['product_id'] ?>">
                                                        <i class="fa fa-trash-o"> </i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="9" class="text-center">No products found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        // Populate the edit modal with product data
        $(document).ready(function() {
            $(".toast").toast("show");

            $(document).on("click", ".open-modal", function() {
                let type = $(this).data("type"); // ✅ Define 'type'
                let product_id = $(this).data("id");
                let product_title = $(this).data("title") || '';
                let category = $(this).data("category") || '';
                let vendor = $(this).data("vendor") || '';
                let stock = $(this).data("stock") || 0;
                let buy_price = $(this).data("buy") || 0;
                let sell_price = $(this).data("sell") || 0;

                if (type === "edit") {
                    $("#modalTitle").text("Edit Product");
                    $("#modalBody").html(`
                <form action="update_product.php" method="POST">
                    <input type="hidden" name="product_id" value="${product_id}">

                    <div class="form-group">
                        <label>Product Title:</label>
                        <input type="text" class="form-control" name="product_title" value="${product_title}" required>
                    </div>

                    <div class="form-group">
                        <label>Category:</label>
                        <select class="form-control" name="category_id" required>
                            <option value="" disabled>Select Category</option>
                            <?php foreach ($categories as $c) : ?>
                                <option value="<?= $c['category_id'] ?>" ${category === "<?= htmlspecialchars($c['category_name']) ?>" ? 'selected' : ''}>
                                    <?= htmlspecialchars($c['category_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Vendor:</label>
                        <select class="form-control" name="vendor_id" required>
                            <option value="" disabled>Select Vendor</option>
                            <?php foreach ($vendors as $v) : ?>
                                <option value="<?= $v['vendor_id'] ?>" ${vendor === "<?= htmlspecialchars($v['vendor_name']) ?>" ? 'selected' : ''}>
                                    <?= htmlspecialchars($v['vendor_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Stock:</label>
                        <input type="number" class="form-control" name="in_stock" value="${stock}" required>
                    </div>

                    <div class="form-group">
                        <label>Buy Price:</label>
                        <input type="number" step="0.01" class="form-control" name="buying_price" value="${buy_price}" required>
                    </div>

                    <div class="form-group">
                        <label>Sell Price:</label>
                        <input type="number" step="0.01" class="form-control" name="selling_price" value="${sell_price}" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            `);
                    $("#modalFooter").html('');
                } else if (type === "delete") {
                    $("#modalTitle").text("Confirm Deletion");
                    $("#modalBody").html("<p>Are you sure you want to delete this product?</p>");
                    $("#modalFooter").html(`
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <a href="delete_product.php?id=${product_id}" class="btn btn-danger">Delete</a>
            `);
                }
            });
        });
    </script>
    <script src="script.js"></script>
</body>

</html>