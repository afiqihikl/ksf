document.addEventListener("DOMContentLoaded", function () {
  const ctx = document.getElementById("salesChart").getContext("2d");

  let chart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: [],
      datasets: [
        {
          label: "Data",
          data: [],
          backgroundColor: "rgba(0, 123, 255, 0.5)",
        },
      ],
    },
  });

  function updateChart(filters) {
    const startDate = document.getElementById("startDate").value;
    const endDate = document.getElementById("endDate").value;

    fetch("trychart_data.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        filters: filters,
        startDate: startDate,
        endDate: endDate,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        chart.data.labels = data.labels;
        chart.data.datasets[0].data = data.values;
        chart.data.datasets[0].label = data.label;
        chart.update();
      });
  }

  document
    .getElementById("filterSelect")
    .addEventListener("change", function () {
      const selectedFilter = this.value;
      const dateRange = document.getElementById("dateRange");

      if (
        selectedFilter === "monthly_sales" ||
        selectedFilter === "weekly_sales"
      ) {
        dateRange.style.display = "block";
      } else {
        dateRange.style.display = "none";
      }

      updateChart([selectedFilter]);
    });

  // Trigger update on date change too
  document.getElementById("startDate").addEventListener("change", () => {
    updateChart([document.getElementById("filterSelect").value]);
  });
  document.getElementById("endDate").addEventListener("change", () => {
    updateChart([document.getElementById("filterSelect").value]);
  });

  // Initial chart
  updateChart([]);
});
