document.addEventListener("DOMContentLoaded", function () {
  const options = {
    pageLength: 5,
    lengthMenu: [5, 10, 25, 50, 100],
    paging: true,
    searching: true,
    ordering: true,
    responsive: true,
  };

  // List of all tables to apply dynamic numbering to
  const tableIds = ["#ksfTable1", "#ksfTable2", "#ksfTable3", "#ksfTable4"];

  tableIds.forEach((id) => {
    const table = new DataTable(id, {
      ...options,
      columnDefs: [
        {
          searchable: false,
          orderable: false,
          targets: 0, // Disable sort and search on first column
        },
      ],
      order: [[1, "asc"]], // Default sort by second column
    });

    // Event for dynamic numbering
    table.on("order.dt search.dt draw.dt", function () {
      table
        .column(0, { search: "applied", order: "applied" })
        .nodes()
        .each(function (cell, i) {
          cell.innerHTML = i + 1;
        });
    });

    table.draw();
  });
});
