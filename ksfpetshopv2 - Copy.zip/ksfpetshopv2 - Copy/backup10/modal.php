<!-- modal.php -->
<div class="modal fade" id="universalModal" tabindex="-1" role="dialog" aria-labelledby="universalModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="modalTitle"></h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body" id="modalBody">
                <!-- Content will be injected dynamically -->
            </div>
            <div class="modal-footer" id="modalFooter">
                <!-- Buttons will be injected dynamically -->
            </div>
        </div>
    </div>
</div>
