<?php
include 'db.php';
include 'sidebar.php';

// Fetch sales data using PDO
$query = "SELECT s.sales_id, p.product_title, s.total_sales AS quantity, 
                 (s.total_sales * p.selling_price) AS total_price, s.date 
          FROM sales s
          JOIN products p ON s.product_id = p.product_id
          ORDER BY s.date DESC";


$stmt = $pdo->prepare($query);
$stmt->execute();
$sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.css" />
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">SALES</h1>

        <div class="row">
            <div class="col-12">
                <div class="card" style="height:100%">
                    <div class="card-header">
                        <div class="d-flex justify-content-end ">
                            <button type="button" class="btn btn-primary" onclick="window.location='new_sales.php'"><i class='fa fa-plus-circle'></i> Add Sales</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table id="ksfTable1" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Product Title</th>
                                        <th>Total</th>
                                        <th>Total</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                if (count($sales) > 0) {
                                    $counter = 1; // Initialize counter   <a href='edit_sales.php?id={$row['sales_id']}' class='btn btn-sm btn-secondary'><i class='fa fa-edit'></i> Edit</a>
                                    foreach ($sales as $row) {
                                        echo "<tr>
                                                <td>{$counter}</td>
                                                <td>{$row['product_title']}</td>
                                                <td>{$row['total_price']}</td>
                                                <td>{$row['quantity']}</td>
                                                <td>{$row['date']}</td>
                                                <td>
                                                    
                                                    <a href='delete_sales.php?id={$row['sales_id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure?\")'><i class='fa fa-trash-o'></i> </a>
                                                </td>
                                            </tr>";
                                        $counter++; // Increment counter
                                    }
                                } else {
                                    echo "<tr><td colspan='5' class='text-center'>No sales recorded</td></tr>";
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>

</html>