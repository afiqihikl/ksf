<?php
include 'db.php';

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $product_id = intval($_GET['id']);

    try {
        // Prepare delete query
        $query = "DELETE FROM products WHERE product_id = :product_id";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->execute();

        // Redirect with success message
        header("Location: product.php?status=success");
        exit();
    } catch (PDOException $e) {
        // Redirect with error message
        header("Location: product.php?status=error&message=" . urlencode($e->getMessage()));
        exit();
    }
} else {
    // Redirect if ID is not valid
    header("Location: product.php?status=error&message=Invalid ID");
    exit();
}
?>
