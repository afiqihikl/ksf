<?php
include 'db.php';

if (isset($_GET['id'])) {
    $sales_id = $_GET['id'];

    try {
        // Delete the sales record
        $query = "DELETE FROM sales WHERE sales_id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$sales_id]);

        if ($stmt->rowCount() > 0) {
            $message = "Sale record deleted successfully";
        } else {
            $message = "Sale record not found";
        }
    } catch (PDOException $e) {
        $message = "Error deleting sale record";
    }
} else {
    $message = "Invalid request";
}

// Redirect back to sales page with message
header("Location: sales.php?message=" . urlencode($message));
exit();
?>
