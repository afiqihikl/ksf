<?php
session_start();
include 'db.php';
include 'toast.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_id = $_POST['category_id'] ?? null;
    $category_name = htmlspecialchars($_POST['category_name'] ?? '');

    if ($category_id && !empty($category_name)) {
        try {
            $stmt = $pdo->prepare("UPDATE category SET category_name = :category_name WHERE category_id = :category_id");
            $stmt->execute([
                ':category_name' => $category_name,
                ':category_id' => $category_id
            ]);


            $_SESSION['toast_message'] = "Category updated successfully!";
            $_SESSION['toast_type'] = "success";
        } catch (PDOException $e) {
            $_SESSION['toast_message'] = "Error updating category: " . $e->getMessage();
            $_SESSION['toast_type'] = "danger";
        }
    } else {
        $_SESSION['toast_message'] = "Category name cannot be empty.";
        $_SESSION['toast_type'] = "danger";
    }
}

header("Location: category.php");
exit;
?>
