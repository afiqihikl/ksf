<?php
session_start();
date_default_timezone_set('Asia/Kuala_Lumpur');

include 'db.php';

// Ensure user is authenticated
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

$user_id = $_SESSION['user_id'];
$company_name = "KSF Pet Shop";

// Decode JSON input
$rawData = file_get_contents("php://input");
$data = json_decode($rawData, true);
$cart_items = $data['cart'] ?? [];

if (empty($cart_items)) {
    echo json_encode(['success' => false, 'message' => 'Cart is empty']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Insert into sales table
    $sale_date = date('Y-m-d H:i:s');
    $stmt = $pdo->prepare("INSERT INTO sales (sale_date) VALUES (:sale_date)");
    $stmt->execute(['sale_date' => $sale_date]);
    $sale_id = $pdo->lastInsertId();

    // Prepare insert for sale_items
    $sale_stmt = $pdo->prepare("INSERT INTO sale_items (sale_id, product_id, quantity, price, total) 
                                VALUES (:sale_id, :product_id, :quantity, :price, :total)");

    // Total for invoice
    $total_amount = 0;

    // Loop through each item
    foreach ($cart_items as $item) {
        $product_id = intval($item['id']);
        $quantity = intval($item['quantity']);
        $price = floatval($item['price']);
        $subtotal = $quantity * $price;

        // Validate quantity
        if ($quantity <= 0) {
            throw new Exception("Invalid quantity for product ID $product_id");
        }

        // Check product exists and stock is enough
        $check = $pdo->prepare("SELECT * FROM products WHERE product_id = ?");
        $check->execute([$product_id]);
        $product = $check->fetch();

        if (!$product) {
            throw new Exception("Product not found: ID $product_id");
        }

        if ($quantity > $product['in_stock']) {
            throw new Exception("Insufficient stock for product ID $product_id");
        }

        // Insert sale item
        $sale_stmt->execute([
            'sale_id' => $sale_id,
            'product_id' => $product_id,
            'quantity' => $quantity,
            'price' => $price,
            'total' => $subtotal
        ]);

        // Deduct stock
        $stock_stmt = $pdo->prepare("UPDATE products SET in_stock = in_stock - ? WHERE product_id = ?");
        $stock_stmt->execute([$quantity, $product_id]);

        $total_amount += $subtotal;
    }

    // Create invoice
    $invoice_number = uniqid("INV-");
    $stmt = $pdo->prepare("INSERT INTO invoices (invoice_number, invoice_date, company_name, user_id, total_amount)
                           VALUES (:invoice_number, :invoice_date, :company_name, :user_id, :total_amount)");
    $stmt->execute([
        'invoice_number' => $invoice_number,
        'invoice_date' => $sale_date,
        'company_name' => $company_name,
        'user_id' => $user_id,
        'total_amount' => $total_amount,
    ]);
    $invoice_id = $pdo->lastInsertId();

    // Insert invoice items
    $invoice_stmt = $pdo->prepare("INSERT INTO invoice_items (invoice_id, product_id, quantity, price, total, product_code)
                                   VALUES (:invoice_id, :product_id, :quantity, :price, :total, :product_code)");

    foreach ($cart_items as $item) {
        $subtotal = $item['price'] * $item['quantity'];
        $invoice_stmt->execute([
            'invoice_id' => $invoice_id,
            'product_id' => $item['id'],
            'quantity' => $item['quantity'],
            'price' => $item['price'],
            'total' => $subtotal,
            'product_code' => $item['code'] ?? 'N/A',
        ]);
    }

    $pdo->commit();

    echo json_encode(['success' => true, 'sale_id' => $sale_id, 'invoice_id' => $invoice_id]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Transaction failed: ' . $e->getMessage()]);
}
?>
