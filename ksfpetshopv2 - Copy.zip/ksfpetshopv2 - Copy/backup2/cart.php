<?php
include 'db.php';
include 'sidebar.php';
session_start();
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];

// Check if the cart is empty
if (empty($cart)) {
    $cartEmpty = true;
} else {
    $cartEmpty = false;
    // Fetch real-time stock from the database for each product in the cart
    foreach ($cart as $id => $item) {
        $query = $pdo->prepare("SELECT in_stock FROM products WHERE product_id = ?");
        $query->execute([$id]);
        $product = $query->fetch(PDO::FETCH_ASSOC);

        if ($product) {
            $_SESSION['cart'][$id]["in_stock"] = $product["in_stock"]; // Update stock value in session
        } else {
            $_SESSION['cart'][$id]["in_stock"] = 0; // Product no longer available
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="content">
        <h2>Your Shopping Cart</h2>

        <?php if ($cartEmpty): ?>
            <p>Your cart is empty.</p>
            <button type="button" class="btn btn-primary" onclick="window.location='new_sales.php'">Continue Shopping</button>
        <?php else: ?>
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive-sm">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Product Title</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $grandTotal = 0; ?>
                                <?php foreach ($_SESSION['cart'] as $id => $item): ?>
                                    <?php
                                    $total = $item["selling_price"] * $item["quantity"];
                                    $stock = $item["in_stock"];
                                    ?>
                                    <tr data-id="<?= $id ?>" data-price="<?= $item['selling_price'] ?>" data-instock="<?= $stock ?>">
                                        <td><?= htmlspecialchars($item["product_title"]) ?></td>
                                        <td>$<?= number_format($item["selling_price"], 2) ?></td>
                                        <td>
                                            <div class="input-group quantity-container" style="max-width: 150px;">
                                                <button class="btn btn-outline-secondary decrease" type="button">-</button>
                                                <input type="number" class="form-control text-center qty-input" name="quantity" value="<?= $item["quantity"] ?>" min="1" max="<?= $stock ?>">
                                                <button class="btn btn-outline-secondary increase" type="button">+</button>
                                            </div>
                                            <p class="text-muted">Stock: <?= $stock ?></p>
                                        </td>
                                        <td class="total-price">$<?= number_format($total, 2) ?></td>
                                        <td>
                                            <form action="remove_cart.php" method="POST">
                                                <input type="hidden" name="product_id" value="<?= $id ?>">
                                                <button type="submit" class="btn btn-primary">Remove</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php $grandTotal += $total; ?>
                                <?php endforeach; ?>
                                <tr>
                                    <td colspan="3"><strong>Grand Total:</strong></td>
                                    <td id="grand-total"><strong>$<?= number_format($grandTotal, 2) ?></strong></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <br>
                    <div class="input-group">
                        <form action="checkout.php" method="POST">
                            <button type="submit" class="btn btn-primary mr-1">Proceed to Checkout</button>
                        </form>
                        <button type="button" class="btn btn-primary" onclick="window.location='new_sales.php'">Continue Shopping</button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            function updateCart(productId, newQuantity) {
                fetch('update_cart.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: `product_id=${productId}&quantity=${newQuantity}`
                });
            }

            function updateGrandTotal() {
                let grandTotal = 0;
                document.querySelectorAll(".total-price").forEach(totalPriceElement => {
                    grandTotal += parseFloat(totalPriceElement.textContent.replace("$", "")) || 0;
                });
                document.getElementById("grand-total").textContent = "$" + grandTotal.toFixed(2);
            }

            document.querySelectorAll("tr[data-id]").forEach(row => {
                let qtyInput = row.querySelector(".qty-input");
                let productId = row.getAttribute("data-id");
                let price = parseFloat(row.getAttribute("data-price"));
                let stock = parseInt(row.getAttribute("data-instock"));
                let totalPriceElement = row.querySelector(".total-price");
                let increaseBtn = row.querySelector(".increase");
                let decreaseBtn = row.querySelector(".decrease");

                function updateTotal() {
                    let qty = parseInt(qtyInput.value) || 1;
                    let total = price * qty;
                    totalPriceElement.textContent = "$" + total.toFixed(2);
                    updateGrandTotal();
                }

                increaseBtn.addEventListener("click", function() {
                    let currentQty = parseInt(qtyInput.value);
                    if (currentQty < stock) {
                        qtyInput.value = currentQty + 1;
                        updateCart(productId, qtyInput.value);
                        updateTotal();
                    } else {
                        alert("Not enough stock available!");
                    }
                });

                decreaseBtn.addEventListener("click", function() {
                    if (qtyInput.value > 1) {
                        qtyInput.value = parseInt(qtyInput.value) - 1;
                        updateCart(productId, qtyInput.value);
                        updateTotal();
                    }
                });

                qtyInput.addEventListener("input", function() {
                    let newQty = parseInt(qtyInput.value) || 1;
                    if (newQty > stock) {
                        alert("Not enough stock available!");
                        qtyInput.value = stock;
                    } else if (newQty < 1) {
                        qtyInput.value = 1;
                    }
                    updateCart(productId, newQty);
                    updateTotal();
                });

                updateTotal();
            });
        });
    </script>
</body>

</html>