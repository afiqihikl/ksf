<?php
include 'db.php';
include 'sidebar.php';

// Fetch products with category and vendor details
$query = "SELECT 
            p.product_id, 
            p.photos, 
            p.product_title, 
            c.category_name, 
            v.vendor_name, 
            p.in_stock, 
            p.buying_price, 
            p.selling_price,
            p.product_code 
          FROM products p
          JOIN category c ON p.category_id = c.category_id
          JOIN vendors v ON p.vendor_id = v.vendor_id";

$products = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
// Fetch categories from the database
$categories = $pdo->query("SELECT * FROM category")->fetchAll(PDO::FETCH_ASSOC);
// Fetch vendors from the database
$vendors = $pdo->query("SELECT * FROM vendors")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">PRODUCT</h1>

        <div class="row">
            <div class="col-12">
                <div class="card" style="height:100%">
                    <div class="card-header">
                        <div class="d-flex justify-content-end ">
                            <button type="button" class="btn btn-primary mr-2" onclick="window.location='new_product.php'"><i class='fa fa-plus-circle'></i> New Product</button>
                            <button type="button" class="btn btn-secondary mr-2" onclick="window.location='stock-in.php'"><i class='fa fa-plus-circle'></i> stock in</button>
                            <button type="button" class="btn btn-secondary mr-2" onclick="window.location='stock-out.php'"><i class='fa fa-plus-circle'></i> stock out</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Photo</th>
                                        <th>Product Title</th>
                                        <th>Product Code</th>
                                        <th>Category</th>
                                        <th>Vendor Name</th>
                                        <th>In Stock</th>
                                        <th>Buy Price</th>
                                        <th>Sell Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($products)): ?>
                                        <?php foreach ($products as $index => $product): ?>
                                            <tr>
                                                <td><?= $index + 1 ?></td>
                                                <td>
                                                    <?php if (!empty($product['photos'])): ?>
                                                        <img src="<?= htmlspecialchars($product['photos']) ?>" alt="Product Image" width="50">
                                                    <?php else: ?>
                                                        No Image
                                                    <?php endif; ?>
                                                </td>
                                                <td><?= htmlspecialchars($product['product_title']) ?></td>
                                                <td><?= htmlspecialchars($product['product_code']) ?></td>
                                                <td><?= htmlspecialchars($product['category_name']) ?></td>
                                                <td><?= htmlspecialchars($product['vendor_name']) ?></td>
                                                <td><?= $product['in_stock'] ?></td>
                                                <td>$<?= number_format($product['buying_price'], 2) ?></td>
                                                <td>$<?= number_format($product['selling_price'], 2) ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-secondary btn-sm edit-btn"
                                                        data-toggle="modal"
                                                        data-target="#editModal"
                                                        data-id="<?= $product['product_id'] ?>"
                                                        data-title="<?= htmlspecialchars($product['product_title']) ?>"
                                                        data-category="<?= htmlspecialchars($product['category_name']) ?>"
                                                        data-vendor="<?= htmlspecialchars($product['vendor_name']) ?>"
                                                        data-stock="<?= $product['in_stock'] ?>"
                                                        data-buy="<?= $product['buying_price'] ?>"
                                                        data-sell="<?= $product['selling_price'] ?>"><i class="fa fa-edit"></i>
                                                        Edit
                                                    </button>
                                                    <a href="delete_product.php?id=<?= $product['product_id'] ?>" class="btn btn-danger btn-sm"
                                                        onclick="return confirm('Are you sure you want to delete this product?');"><i class="fa fa-trash-o"></i>
                                                        Delete
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="9" class="text-center">No products found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Product Modal -->
    <div class="modal fade" id="editModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Edit Product</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal Body -->
                <div class="modal-body">
                    <form action="update_product.php" method="POST">
                        <input type="hidden" id="edit_product_id" name="product_id">

                        <div class="form-group">
                            <label for="edit_product_title">Product Title:</label>
                            <input type="text" class="form-control" id="edit_product_title" name="product_title" required>
                        </div>

                        <div class="form-group">
                            <label for="edit_category">Category:</label>
                            <input type="text" class="form-control" id="edit_category" name="category_name" readonly>
                            <select class="form-control" name="category" required>
                                <option value="" disabled selected>Select Category</option>
                                <?php foreach ($categories as $category) : ?>
                                    <option value="<?= $category['category_id'] ?>"><?= htmlspecialchars($category['category_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="edit_vendor">Vendor:</label>
                            <input type="text" class="form-control" id="edit_vendor" name="vendor_name" readonly>
                            <select class="form-control" name="vendor_name" required>
                                <option value="" disabled selected>Select Vendor</option>
                                <?php foreach ($vendors as $vendor) : ?>
                                    <option value="<?= $vendor['vendor_id'] ?>"><?= htmlspecialchars($vendor['vendor_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="edit_stock">Stock:</label>
                            <input type="number" class="form-control" id="edit_stock" name="in_stock" required>
                        </div>

                        <div class="form-group">
                            <label for="edit_buying_price">Buy Price:</label>
                            <input type="number" step="0.01" class="form-control" id="edit_buying_price" name="buying_price" required>
                        </div>

                        <div class="form-group">
                            <label for="edit_selling_price">Sell Price:</label>
                            <input type="number" step="0.01" class="form-control" id="edit_selling_price" name="selling_price" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Populate the edit modal with product data
        $(document).on("click", ".edit-btn", function() {
            let product_id = $(this).data("id");
            let product_title = $(this).data("title");
            let category = $(this).data("category");
            let vendor = $(this).data("vendor");
            let stock = $(this).data("stock");
            let buy_price = $(this).data("buy");
            let sell_price = $(this).data("sell");

            $("#edit_product_id").val(product_id);
            $("#edit_product_title").val(product_title);
            $("#edit_category").val(category);
            $("#edit_vendor").val(vendor);
            $("#edit_stock").val(stock);
            $("#edit_buying_price").val(buy_price);
            $("#edit_selling_price").val(sell_price);
        });
    </script>
</body>

</html>