<?php
// Start session if not already started
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Function to set toast messages
function setToast($type, $message)
{
    $_SESSION['toast'] = [
        'type' => $type,  // success, danger, warning, info
        'message' => $message
    ];
}

// Function to display toast messages
function displayToast()
{
    if (!empty($_SESSION['toast'])) {
        $toast = $_SESSION['toast'];
        $type = ($toast['type'] === 'success') ? 'bg-success' :
            (($toast['type'] === 'danger') ? 'bg-danger' :
                (($toast['type'] === 'warning') ? 'bg-warning' : 'bg-info'));

        echo '
        <div aria-live="polite" aria-atomic="true">
            <div style="position: fixed; top: 10px; right: 10px; z-index: 1050;">
                <div class="toast ' . $type . ' text-white" data-autohide="true" data-delay="3000">
                    <div class="toast-header">
                        <strong class="mr-auto">' . ucfirst($toast['type']) . '</strong>
                        <button type="button" class="ml-2 mb-1 close" data-dismiss="toast">&times;</button>
                    </div>
                    <div class="toast-body">' . htmlspecialchars($toast['message']) . '</div>
                </div>
            </div>
        </div>
        <script>$(document).ready(function () { $(".toast").toast("show"); });</script>
        ';
        
        // Remove toast after displaying
        unset($_SESSION['toast']);
    }
}
?>
