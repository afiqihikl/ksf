<?php
include 'db.php';

// Handle form submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullName = $_POST['full_name'] ?? '';
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $roleId = $_POST['role_id'] ?? '';

    // Input validation
    if (empty($fullName) || empty($username) || empty($password) || empty($roleId)) {
        $message = "All fields are required.";
    } else {
        // Check if username already exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetchColumn() > 0) {
            $message = "Username is already taken.";
        } else {
            // Hash the password
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

            // Insert user into the database
            $stmt = $pdo->prepare("INSERT INTO users (full_name, username, password, role_id) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$fullName, $username, $hashedPassword, $roleId])) {
                $message = "Registration successful!";
            } else {
                $message = "Registration failed. Please try again.";
            }
        }
    }
}

// Fetch roles
$roles = $pdo->query("SELECT role_id, role_name FROM roles")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(to right, rgb(232, 226, 238), rgb(116, 131, 157));
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            font-family: Arial, sans-serif;
            color: white;
        }

        .register-container {
            background: rgb(0, 25, 67);
            border-radius: 10px;
            padding: 20px 30px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }

        .register-container h2 {
            margin-bottom: 20px;
            color: white;
            text-align: center;
        }

        .form-control {
            background-color: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
        }

        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.3);
            box-shadow: none;
            border: none;
        }

        /* .btn-primary {
            background-color: #ff7e5f;
            border: none;
        } */
        /* .btn-primary:hover {
            background-color: #feb47b;
        } */
        .message {
            color: white;
            background-color: rgba(0, 0, 0, 0.5);
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="register-container">
        <h2 style="color:  rgb(199, 156, 2);">KSF Pet Shop</h2>
        <h3 style="color:  rgb(199, 156, 2); text-align: center;">Register</h3>
        <?php if ($message) : ?>
            <div class="message"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <form method="POST" action="register.php">
            <div class="mb-3">
                <label for="full_name" style="color:  rgb(199, 156, 2);" class="form-label">Full Name</label>
                <input type="text" style="color: white;" class="form-control" id="full_name" name="full_name" placeholder="Enter your full name" required>
            </div>
            <div class="mb-3">
                <label for="username" style="color:  rgb(199, 156, 2);" class="form-label">Username</label>
                <input type="text" style="color: white;" class="form-control" id="username" name="username" placeholder="Enter your username" required>
            </div>
            <div class="mb-3">
                <label for="password" style="color:  rgb(199, 156, 2);" class="form-label">Password</label>
                <input type="password" style="color: white;" class="form-control" id="password" name="password" placeholder="Enter your password" required>
            </div>
            <div class="mb-3">
                <label for="role_id" style="color:  rgb(199, 156, 2);" class="form-label">Role</label>
                <select class="form-select" id="role_id" name="role_id" required>
                    <option value="" selected disabled>Select a role</option>
                    <?php foreach ($roles as $role) : ?>
                        <option value="<?= htmlspecialchars($role['role_id']) ?>"><?= htmlspecialchars($role['role_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" style="background-color:  rgb(199, 156, 2);" class="btn w-100">Register</button>
            <div class="mb-3 text-center">
            Already have an account?<a href="login.php" class="text-decoration-none"> Login here</a>
            </div>
        </form>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>