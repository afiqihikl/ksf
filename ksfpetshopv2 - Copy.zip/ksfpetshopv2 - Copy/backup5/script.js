document.addEventListener('DOMContentLoaded', function() {
    const options = {
        pageLength: 5,
        lengthMenu: [5, 10, 25, 50, 100],
        paging: true,
        searching: true,
        ordering: true,
        responsive: true
    };

    new DataTable('#ksfTable1', options);
    new DataTable('#ksfTable2', options);
    new DataTable('#ksfTable3', options);
});

        // Initialize DataTable
        //let table = new DataTable('#ksfTable1');

        let cart = [];
        const cartContainer = document.getElementById('cart-items');
        const totalContainer = document.getElementById('cart-total');

        function saveCart() {
            localStorage.setItem('ksf_cart', JSON.stringify(cart));
        }

        function loadCart() {
            const storedCart = localStorage.getItem('ksf_cart');
            if (storedCart) {
                cart = JSON.parse(storedCart);
            }
        }

        function updateCartUI() {
            cartContainer.innerHTML = '';
            let total = 0;

            if (cart.length === 0) {
                cartContainer.innerHTML = '<p class="text-center text-muted">Cart is empty</p>';
            } else {
                cart.forEach((item, index) => {
                    const subtotal = item.price * item.quantity;
                    total += subtotal;

                    const row = document.createElement('div');
                    row.classList.add('d-flex', 'justify-content-between', 'align-items-center', 'border-bottom', 'py-2');
                    row.innerHTML = `
                        <div>
                            <strong>${item.title}</strong><br>
                            <div class="input-group input-group-sm mt-1">
                                <button class="btn btn-outline-secondary" onclick="changeQuantity(${index}, -1)" ${item.quantity <= 1 ? 'disabled' : ''}>-</button>
                                <input type="text" class="form-control text-center mx-1" style="max-width:50px;" value="${item.quantity}" readonly>
                                <button class="btn btn-outline-secondary" onclick="changeQuantity(${index}, 1)" ${item.quantity >= item.stock ? 'disabled' : ''}>+</button>
                            </div>
                        </div>
                        <div>
                            RM${subtotal.toFixed(2)}
                            <button class="btn btn-sm btn-danger ml-2" onclick="removeItem(${index})">
                                <i class="fa fa-trash"></i>
                            </button>
                        </div>
                    `;
                    cartContainer.appendChild(row);
                });
            }

            totalContainer.textContent = `RM${total.toFixed(2)}`;
            saveCart();
        }

        function addToCart(id, title, price, maxStock) {
            if (maxStock <= 0) {
                alert("This product is out of stock.");
                return;
            }
        
            const existing = cart.find(item => item.id === id);
            if (existing) {
                if (existing.quantity >= maxStock) {
                    alert("You've reached the maximum stock available for this product.");
                    return;
                }
                existing.quantity++;
            } else {
                cart.push({
                    id,
                    title,
                    price,
                    quantity: 1,
                    stock: maxStock
                });
            }
            updateCartUI();
        }
        

        function removeItem(index) {
            cart.splice(index, 1);
            updateCartUI();
        }

        function clearCart() {
            if (confirm('Clear all items from the cart?')) {
                cart = [];
                updateCartUI();
            }
        }

        function changeQuantity(index, change) {
            const item = cart[index];
            const newQty = item.quantity + change;

            if (newQty >= 1 && newQty <= item.stock) {
                item.quantity = newQty;
                updateCartUI();
            }
        }

        loadCart();
        updateCartUI();

        // ✅ EVENT DELEGATION: Handles pagination-related dynamic DOM
        document.addEventListener('click', function(e) {
            if (e.target.closest('.add-to-cart-btn')) {
                const button = e.target.closest('.add-to-cart-btn');
                const row = button.closest('tr');
        
                const id = parseInt(button.dataset.id); // ✅ Use data-id, which is the real product_id
                const title = row.children[2].textContent.trim();
                const price = parseFloat(row.children[5].textContent.replace('RM', ''));
                const stock = parseInt(row.children[4].textContent);
        
                addToCart(id, title, price, stock);
            }
        });
               
        document.getElementById('barcodeInput').addEventListener('input', function(e) {
            const value = e.target.value.trim();

            // Automatically search and add if exactly 8 digits
            if (/^\d{8}$/.test(value)) {
                const tableRows = document.querySelectorAll('#ksfTable1 tbody tr');
                let found = false;

                tableRows.forEach(row => {
                    const barcode = row.children[3].textContent.trim(); // Product Code column
                    if (barcode === value) {
                        const id = row.children[0].textContent.trim();
                        const title = row.children[2].textContent.trim();
                        const price = parseFloat(row.children[5].textContent.replace('RM', ''));
                        const stock = parseInt(row.children[4].textContent);

                        addToCart(id, title, price, stock);
                        found = true;
                    }
                });

                if (!found) {
                    alert("Product not found.");
                }

                // Clear the input after action
                e.target.value = '';
            }
        });

        //add payment

        function completePayment() {
            if (cart.length === 0) {
                alert("Cart is empty!");
                return;
            }
        
            fetch('add_to_sales.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ cart })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("Payment completed successfully!");
                    cart = [];           // ✅ Clear cart directly
                    updateCartUI();      // ✅ Refresh UI without confirmation
                    location.reload();   // 🔁 Refresh page
                } else {
                    alert("Error: " + data.message);
                }
            })            
            .catch(error => {
                console.error('Error:', error);
                alert("Something went wrong.");
            });
        }
        