<?php
session_start();
include 'db.php';
include 'toast.php';

if (isset($_GET['id'])) {
    $vendor_id = intval($_GET['id']);

    try {
        $stmt = $pdo->prepare("DELETE FROM vendors WHERE vendor_id = :vendor_id");
        $stmt->execute([':vendor_id' => $vendor_id]);

        $_SESSION['toast_message'] = "Vendor deleted successfully!";
        $_SESSION['toast_type'] = "success";
    } catch (PDOException $e) {
        $_SESSION['toast_message'] = "Error deleting vendor: " . $e->getMessage();
        $_SESSION['toast_type'] = "danger";
    }
}

header("Location: vendor.php");
exit;
