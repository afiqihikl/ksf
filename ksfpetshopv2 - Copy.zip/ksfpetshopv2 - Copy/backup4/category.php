<?php
ob_start(); // ✅ Start output buffering
include 'db.php';
include 'sidebar.php';
include 'toast.php';
include 'modal.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_name = htmlspecialchars($_POST['category'] ?? '');

    if (!empty($category_name)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO category (category_name) VALUES (:category_name)");
            $stmt->execute([':category_name' => $category_name]);

            // ✅ Use universal toast function
            setToast('success', 'Category added successfully!');
        } catch (PDOException $e) {
            setToast('danger', 'Error adding category: ' . $e->getMessage());
        }
    } else {
        setToast('danger', 'Category name cannot be empty.');
    }

    header("Location: category.php");
    exit;
}

$query = "SELECT * FROM category";
$stmt = $pdo->query($query);
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.css" />
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
</head>

<body>
    <!-- ✅ Display Universal Toast -->
    <?php displayToast(); ?>

    <div class="content" id="content">
        <h1 class="mt-4">Category</h1>

        <div class="row">
            <div class="col-6">
                <div class="card" style="height:100%">
                    <div class="card-header">ADD NEW CATEGORY</div>
                    <div class="card-body">
                        <form action="category.php" method="POST">
                            <div class="form-group">
                                <label for="category_name">Category Name:</label>
                                <input type="text" class="form-control" placeholder="Enter Category Name" id="category" name="category">
                            </div>
                            <button type="submit" class="btn btn-primary" style="width:100%">Submit</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-6">
                <div class="card" style="height:100%">
                    <div class="card-header">ALL CATEGORY</div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table id="ksfTable1" class=" table table-bordered text-center">
                                <thead class="">
                                    <tr>
                                        <th>#</th>
                                        <th>Category</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($categories as $index => $category) : ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td><?= htmlspecialchars($category['category_name']) ?></td>
                                            <td>
                                                <!-- Universal Edit Button -->
                                                <button type="button" class="btn btn-secondary btn-sm open-modal"
                                                    data-toggle="modal"
                                                    data-target="#universalModal"
                                                    data-type="edit"
                                                    data-id="<?= $category['category_id'] ?>"
                                                    data-name="<?= $category['category_name'] ?>">
                                                    <i class="fa fa-edit"></i>
                                                </button>

                                                <!-- Universal Delete Button -->
                                                <button type="button" class="btn btn-danger btn-sm open-modal"
                                                    data-toggle="modal"
                                                    data-target="#universalModal"
                                                    data-type="delete"
                                                    data-id="<?= $category['category_id'] ?>">
                                                    <i class="fa fa-trash-o"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $(".toast").toast("show");

            // Open Modal for Edit or Delete
            $(document).on("click", ".open-modal", function() {
                let type = $(this).data("type");
                let category_id = $(this).data("id");
                let category_name = $(this).data("name") || '';

                if (type === "edit") {
                    $("#modalTitle").text("Edit Category");
                    $("#modalBody").html(`
                    <form action="update_category.php" method="POST">
                        <input type="hidden" name="category_id" value="${category_id}">
                        <div class="form-group">
                            <label for="category_name">Category Name</label>
                            <input type="text" class="form-control" name="category_name" value="${category_name}" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                `);
                    $("#modalFooter").html('');
                } else if (type === "delete") {
                    $("#modalTitle").text("Confirm Deletion");
                    $("#modalBody").html("<p>Are you sure you want to delete this category?</p>");
                    $("#modalFooter").html(`
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <a href="delete_category.php?id=${category_id}" class="btn btn-danger">Delete</a>
                `);
                }
            });
        });
    </script>
    <script src="script.js"></script>
</body>

</html>