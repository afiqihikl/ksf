<?php
include 'db.php';

if (isset($_GET['id'])) {
    $vendor_id = $_GET['id'];

    try {
        // Check if vendor is associated with any products
        $checkQuery = "SELECT COUNT(*) FROM products WHERE vendor_id = :vendor_id";
        $checkStmt = $pdo->prepare($checkQuery);
        $checkStmt->execute([':vendor_id' => $vendor_id]);
        $count = $checkStmt->fetchColumn();

        if ($count > 0) {
            // Redirect with an error message if the vendor has associated products
            header("Location: vendor.php?error=Cannot delete vendor. Associated products exist.");
            exit();
        }

        // Delete vendor if no associated products
        $sql = "DELETE FROM vendors WHERE vendor_id = :vendor_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':vendor_id' => $vendor_id]);

        // Redirect with success message
        header("Location: vendor.php?success=Vendor deleted successfully!");
        exit();
    } catch (PDOException $e) {
        // Redirect with error message
        header("Location: vendor.php?error=Error deleting vendor: " . $e->getMessage());
        exit();
    }
} else {
    // Redirect if accessed incorrectly
    header("Location: vendor.php");
    exit();
}
?>
