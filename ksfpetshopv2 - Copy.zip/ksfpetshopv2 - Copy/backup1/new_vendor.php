<?php
include 'db.php';
include 'sidebar.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vendor_name = $_POST['vendor_name'];
    $vendor_status = $_POST['vendor_status'];
    $vendor_personincharge = $_POST['vendor_personincharge'];
    $vendor_contact = $_POST['vendor_contact'];
    $vendor_address = $_POST['vendor_address'];

    try {
        $sql = "INSERT INTO vendors (vendor_name, vendor_status, vendor_personincharge, vendor_contact, vendor_address) 
                VALUES (:vendor_name, :vendor_status, :vendor_personincharge, :vendor_contact, :vendor_address)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':vendor_name' => $vendor_name,
            ':vendor_status' => $vendor_status,
            ':vendor_personincharge' => $vendor_personincharge,
            ':vendor_contact' => $vendor_contact,
            ':vendor_address' => $vendor_address
        ]);
        
        echo "<script>alert('New supplier added successfully!'); window.location.href='vendor.php';</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href='vendor.php';</script>";
    }
} else {
    // echo "<script>alert('Invalid request!'); window.history.back();</script>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP - Add Product</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">SUPPLIER</h1>
        <div class="card mt-4">
            <div class="card-header">Add New Supplier</div>
            <div class="card-body">
                <form action="new_vendor.php" method="POST">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Company Name" name="vendor_name" required>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <select class="form-control" name="vendor_status" required>
                                    <option value="" disabled selected>Select status</option>
                                    <option value="Active">Active</option>
                                    <option value="Deactive">Deactive</option>
                                </select>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Person In Charge" name="vendor_personincharge" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Contact" name="vendor_contact" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Address" name="vendor_address" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>