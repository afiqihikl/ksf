<?php
include 'db.php';
include 'toast.php';
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $product_id = intval($_GET['id']);

    try {
        // Prepare delete query
        $query = "DELETE FROM products WHERE product_id = :product_id";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->execute();

        // Redirect with success message
        setToast('success', 'Product deleted successfully!');
    } catch (PDOException $e) {
        // Redirect with error message
        setToast('danger', 'Error deleting product: ' . $e->getMessage());
    }
} else {
    // Redirect if ID is not valid
    setToast('danger', 'Invalid product ID.');
}
// Redirect to category.php
header("Location: product.php");
exit;