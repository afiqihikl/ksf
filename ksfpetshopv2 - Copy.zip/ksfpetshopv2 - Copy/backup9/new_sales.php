<?php
include 'sidebar.php';
include 'db.php';

// Fetch products with category and vendor details
$query = "SELECT 
            p.product_id, 
            p.photos, 
            p.product_title, 
            c.category_name, 
            v.vendor_name, 
            v.vendor_address, 
            p.in_stock, 
            p.buying_price, 
            p.selling_price,
            p.product_code 
          FROM products p
          JOIN category c ON p.category_id = c.category_id
          JOIN vendors v ON p.vendor_id = v.vendor_id";

$products = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
$categories = $pdo->query("SELECT * FROM category")->fetchAll(PDO::FETCH_ASSOC);
$vendors = $pdo->query("SELECT * FROM vendors")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.css" />
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">Point of Sale</h1>
        <div class="row mt-4">
            <div class="col-7">
                <div class="card" style="height:100%;">
                    <div style="background-color:rgb(0, 25, 67);" class="card-header text-white">
                        <form action="/action_page.php">
                            <div class="input-group">
                                <span class="input-group-text bg-white"><i class="fa fa-search text-muted"></i></span>
                                <input type="text" class="form-control" placeholder="Search Barcode" id="barcodeInput" aria-label="Search Barcode">
                                <!-- i want to make this search barcode, when accept 8 digit number, it will automatically add to cart -->
                            </div>
                        </form>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table id="ksfTable1" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Photo</th>
                                        <th>Product Title</th>
                                        <th>Product Code</th>
                                        <th>In Stock</th>
                                        <th>Sell Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody style="font-size:14px;">
                                    <?php foreach ($products as $index => $product): ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td>
                                                <?php if (!empty($product['photos'])): ?>
                                                    <img src="<?= htmlspecialchars($product['photos']) ?>" alt="Product Image" width="50">
                                                <?php else: ?>
                                                    No Image
                                                <?php endif; ?>
                                            </td>
                                            <td><?= htmlspecialchars($product['product_title']) ?></td>
                                            <td><?= htmlspecialchars($product['product_code']) ?></td>
                                            <td><?= $product['in_stock'] ?></td>
                                            <td>RM<?= number_format($product['selling_price'], 2) ?></td>
                                            <td style="width:156px;">
                                                <button
                                                    type="button"
                                                    class="btn btn-primary add-to-cart-btn"
                                                    data-id="<?= $product['product_id'] ?>"
                                                    title="Add to Cart">
                                                    <i class="fa fa-shopping-cart"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-5">
                <div class="card" style="height:620px;">
                    <div style="font-size:26px;" class="card-header text-black text-center bg-white">Cart</div>
                    <div class="card-body bg-white" style="height: 400px; overflow-y: auto;" id="cart-items">
                        <!-- Items will be injected here via JS -->
                    </div>
                    <div class="card-footer bg-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Total:</h5>
                            <h5 class="mb-0 text-right"><strong id="cart-total">RM0.00</strong></h5>
                        </div>
                        <div class="text-right mt-2">
                            <button class="btn btn-outline-danger btn-sm" onclick="clearCart()">
                                <i class="fa fa-trash"></i> Clear Cart
                            </button>
                        </div>
                        <div class="text-left mt-2">
                            <button class="btn btn-outline-primary btn-sm" onclick="completePayment()">
                                <i class="fa fa-shopping-cart"></i> Complete Payment
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>

</html>