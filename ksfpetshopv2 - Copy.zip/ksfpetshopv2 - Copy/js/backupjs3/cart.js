let cart = [];
const cartContainer = document.getElementById("cart-items");
const totalContainer = document.getElementById("cart-total");

function saveCart() {
  localStorage.setItem("ksf_cart", JSON.stringify(cart));
}

function loadCart() {
  const storedCart = localStorage.getItem("ksf_cart");
  if (storedCart) {
    cart = JSON.parse(storedCart);
  }
}

function updateCartUI() {
  cartContainer.innerHTML = "";
  let total = 0;

  if (cart.length === 0) {
    cartContainer.innerHTML = '<p class="text-center text-muted">Cart is empty</p>';
  } else {
    cart.forEach((item, index) => {
      const subtotal = item.price * item.quantity;
      total += subtotal;

      const row = document.createElement("div");
      row.classList.add("d-flex", "justify-content-between", "align-items-center", "border-bottom", "py-2");
      row.innerHTML = `
        <div>
          <strong>${item.title}</strong><br>
          <div class="input-group input-group-sm mt-1">
            <button class="btn btn-outline-secondary" onclick="changeQuantity(${index}, -1)" ${item.quantity <= 1 ? "disabled" : ""}>-</button>
            <input type="text" class="form-control text-center mx-1" style="max-width:50px;" value="${item.quantity}" readonly>
            <button class="btn btn-outline-secondary" onclick="changeQuantity(${index}, 1)" ${item.quantity >= item.stock ? "disabled" : ""}>+</button>
          </div>
        </div>
        <div>
          RM${subtotal.toFixed(2)}
          <button class="btn btn-sm btn-danger ml-2" onclick="removeItem(${index})">
            <i class="fa fa-trash"></i>
          </button>
        </div>
      `;
      cartContainer.appendChild(row);
    });
  }

  totalContainer.textContent = `RM${total.toFixed(2)}`;
  saveCart();
}

function addToCart(id, title, price, maxStock) {
  if (maxStock <= 0) {
    ModalManager.show("Out of Stock", "<p>This product is currently out of stock.</p>");
    //please put close button
    return;
  }

  const existing = cart.find((item) => item.id === id);
  if (existing) {
    if (existing.quantity >= maxStock) {
      ModalManager.show("Stock Limit Reached", "<p>You've reached the maximum stock available for this product.</p>");
      //please put close button
      return;
    }
    existing.quantity++;
  } else {
    cart.push({
      id,
      title,
      price,
      quantity: 1,
      stock: maxStock,
    });
  }
  updateCartUI();
}

function removeItem(index) {
  cart.splice(index, 1);
  updateCartUI();
}

function clearCart() {
  ModalManager.confirm("Clear Cart", "Are you sure you want to remove all items from the cart?", function () {
    //please make button No like close button
    cart = [];
    updateCartUI();
  });
}

function changeQuantity(index, change) {
  const item = cart[index];
  const newQty = item.quantity + change;

  if (newQty >= 1 && newQty <= item.stock) {
    item.quantity = newQty;
    updateCartUI();
  }
}

loadCart();
updateCartUI();

document.addEventListener("click", function (e) {
  if (e.target.closest(".add-to-cart-btn")) {
    const button = e.target.closest(".add-to-cart-btn");
    const row = button.closest("tr");

    const id = parseInt(button.dataset.id);
    const title = row.children[2].textContent.trim();
    const price = parseFloat(row.children[5].textContent.replace("RM", ""));
    const stock = parseInt(row.children[4].textContent);

    addToCart(id, title, price, stock);
  }
});

$(document).ready(function () {
  $("#barcodeInput").focus();

  $("#barcodeInput").on("input", function () {
    let barcode = $(this).val();
    if (barcode.length === 8) {
      addToCartByBarcode(barcode);
      $(this).val("").focus();
    }
  });
});

function addToCartByBarcode(barcode) {
  let productRow = $(`#ksfTable1 tbody tr`).filter(function () {
    return $(this).find("td:nth-child(4)").text().trim() === barcode;
  });

  if (productRow.length > 0) {
    let addButton = productRow.find(".add-to-cart-btn");
    addButton.click();
  } else {
    ModalManager.show("Product Not Found", `<p>No product found for barcode: <strong>${barcode}</strong></p>`);
    //please put close button
  }
}

function completePayment(paymentMethod) {
  if (cart.length === 0) {
    ModalManager.show("Cart Empty", "<p>Your cart is empty. Please add items first.</p>");
    //please put close button
    return;
  }

  fetch("add_to_sales.php", {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ cart, payment_method: paymentMethod }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        ModalManager.show(
          "Payment Successful",
          "<p>Your payment has been processed. You can print the invoice now.</p>",
          `<button type="button" class="btn btn-primary" onclick="window.open('invoice_print.php?invoice_id=${data.invoice_id}', '_blank')">Print Invoice</button>
           <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="location.reload()">Close</button>`
        );
        cart = [];
        updateCartUI();
      } else {
        ModalManager.show("Payment Error", `<p>Error: ${data.message}</p>`);
        //please put close button
      }
    })
    .catch((error) => {
      console.error("Error:", error);
      ModalManager.show("Error", "<p>Something went wrong while processing the payment.</p>");
      //please put close button
    });
}

// ✅ Modal Manager Utility
const ModalManager = {
  show: function (title, bodyContent, footerButtons = '<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>') {
    document.getElementById("modalTitle").innerHTML = title;
    document.getElementById("modalBody").innerHTML = bodyContent;
    document.getElementById("modalFooter").innerHTML = footerButtons;
    $("#universalModal").modal("show");
  },

  confirm: function (title, message, onConfirm) {
    this.show(
      title,
      `<p>${message}</p>`,
      `<button type="button" class="btn btn-danger" id="confirmBtn">Yes</button>
       <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>`
    );
    document.getElementById("confirmBtn").onclick = function () {
      $("#universalModal").modal("hide");
      onConfirm();
    };
  }
};
