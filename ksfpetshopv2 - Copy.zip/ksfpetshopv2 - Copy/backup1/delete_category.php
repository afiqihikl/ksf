<?php
include 'db.php'; // Include the database connection

// Check if 'id' parameter is present in the URL
if (isset($_GET['id'])) {
    $category_id = $_GET['id'];

    // Validate the category ID to ensure it's a valid number
    if (filter_var($category_id, FILTER_VALIDATE_INT)) {
        try {
            // Prepare the DELETE query to remove the category
            $stmt = $pdo->prepare("DELETE FROM category WHERE category_id = :category_id");
            $stmt->execute([':category_id' => $category_id]);

            // Redirect back to the page showing categories
            header("Location: category.php"); // Change 'category_list.php' to your page showing the categories
            exit;
        } catch (PDOException $e) {
            // Handle any errors during the deletion process
            echo "Error deleting category: " . $e->getMessage();
        }
    } else {
        // Invalid category ID
        echo "Invalid category ID.";
    }
} else {
    // If 'id' parameter is missing, show an error
    echo "Category ID is required.";
}
?>
