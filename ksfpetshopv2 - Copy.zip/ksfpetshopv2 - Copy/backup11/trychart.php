<?php
include 'sidebar.php';
include 'db.php';
include 'toast.php';

// Check kalau request JSON (AJAX dari Chart.js)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
    $filters = json_decode(file_get_contents('php://input'), true);
    $filter = isset($filters['filters']) && count($filters['filters']) > 0 ? $filters['filters'][0] : 'top_sales';

    switch ($filter) {
        case 'highest_qty':
            $stmt = $pdo->prepare("
                SELECT p.product_title, SUM(si.quantity) AS total_quantity
                FROM sale_items si
                JOIN products p ON si.product_id = p.product_id
                GROUP BY si.product_id
                ORDER BY total_quantity DESC
                LIMIT 10
            ");
            $label = 'Highest Quantity';
            $valueKey = 'total_quantity';
            break;

        case 'top_product_qty':
            $stmt = $pdo->prepare("
                SELECT p.product_title, SUM(si.quantity) AS product_qty
                FROM sale_items si
                JOIN products p ON si.product_id = p.product_id
                GROUP BY si.product_id
                ORDER BY product_qty DESC
                LIMIT 10
            ");
            $label = 'Top Product Quantity';
            $valueKey = 'product_qty';
            break;

        default:
            $stmt = $pdo->prepare("
                SELECT p.product_title, SUM(si.total) AS total_sales
                FROM sale_items si
                JOIN products p ON si.product_id = p.product_id
                GROUP BY si.product_id
                ORDER BY total_sales DESC
                LIMIT 10
            ");
            $label = 'Top Product Sales';
            $valueKey = 'total_sales';
    }

    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $response = [
        'labels' => array_column($data, 'product_title'),
        'values' => array_column($data, $valueKey),
        'label' => $label
    ];

    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">Dashboard</h1>
        <div class="row mt-4">
            <div class="col-12">
                <div class="card" style="height:100%;">
                    <div style="background-color:rgb(0, 25, 67);" class="card-header text-white text-center">Chart</div>
                    <div class="card-body">
                        <form id="chartFilterForm">
                            <label for="filterSelect">Pilih Carta:</label>
                            <select id="filterSelect" name="filter">
                                <option value="top_product_qty">Top Product Quantity</option>
                                <option value="monthly_sales">Monthly Sales Trend</option>
                                <option value="weekly_sales">Weekly Sales</option>
                                <option value="low_stock">Low Stock Products</option>
                                <option value="stock_by_category">Category-wise Stock</option>
                                <option value="top_categories">Top Categories by Sales</option>
                                <option value="no_sales">Products with No Sales</option>
                            </select>
                        </form>
                        <canvas id="salesChart" height="100"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const ctx = document.getElementById('salesChart').getContext('2d');

            let chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Data',
                        data: [],
                        backgroundColor: 'rgba(0, 123, 255, 0.5)'
                    }]
                }
            });

            function updateChart(filters) {
                fetch('trychart_data.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            filters: filters
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        chart.data.labels = data.labels;
                        chart.data.datasets[0].data = data.values;
                        chart.data.datasets[0].label = data.label;
                        chart.update();
                    });
            }

            document.getElementById('filterSelect').addEventListener('change', function() {
                const selectedFilter = this.value;
                updateChart([selectedFilter]);
            });

            // Load default
            updateChart([]);
        });
    </script>
</body>

</html>