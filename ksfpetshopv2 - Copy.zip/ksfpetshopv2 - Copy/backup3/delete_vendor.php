<?php
include 'db.php';
include 'toast.php';

if (isset($_GET['id'])) {
    $vendor_id = intval($_GET['id']);

    try {
        $stmt = $pdo->prepare("DELETE FROM vendors WHERE vendor_id = :vendor_id");
        $stmt->execute([':vendor_id' => $vendor_id]);

        setToast('success', 'Vendor deleted successfully!');
    } catch (PDOException $e) {
        setToast('danger', 'Error deleting vendor: ' . $e->getMessage());
    }
}

header("Location: vendor.php");
exit;
