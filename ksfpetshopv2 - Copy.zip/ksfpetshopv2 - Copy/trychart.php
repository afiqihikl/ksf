<?php
//include 'sidebar.php';
//include 'db.php';
//include 'toast.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <!-- <link rel="stylesheet" href="style.css"> -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<!-- Add to your form in trychart.php -->
<form id="chartFilterForm">
    <label for="filterSelect">Pilih Carta:</label>
    <select id="filterSelect" name="filter">
        <option value="top_product_qty">Top Product Quantity</option>
        <option value="monthly_sales">Monthly Sales Trend</option>
        <option value="weekly_sales">Weekly Sales</option>
        <option value="low_stock">Low Stock Products</option>
        <option value="stock_by_category">Category-wise Stock</option>
        <option value="top_categories">Top Categories by Sales</option>
        <option value="no_sales">Products with No Sales</option>
    </select><br><br>

    <div id="dateRange" style="display:none;">
        <label for="startDate">Start Date:</label>
        <input type="date" id="startDate" name="startDate">
        <label for="endDate">End Date:</label>
        <input type="date" id="endDate" name="endDate">
    </div>
</form>

<canvas id="salesChart" height="100"></canvas>


<script src="js/chart.js"></script>
