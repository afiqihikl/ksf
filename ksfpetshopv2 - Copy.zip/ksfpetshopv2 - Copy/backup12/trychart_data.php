<?php
include 'db.php';

$filters = json_decode(file_get_contents('php://input'), true);
$filter = isset($filters['filters']) && count($filters['filters']) > 0 ? $filters['filters'][0] : 'top_sales';

$startDate = isset($filters['startDate']) && !empty($filters['startDate']) ? $filters['startDate'] : null;
$endDate = isset($filters['endDate']) && !empty($filters['endDate']) ? $filters['endDate'] : null;

switch ($filter) {
    case 'top_quantity':
        $stmt = $pdo->prepare("SELECT p.product_title, SUM(si.quantity) AS value FROM sale_items si JOIN products p ON si.product_id = p.product_id GROUP BY si.product_id ORDER BY value DESC LIMIT 10");
        $label = 'Top Product Quantity Sold';
        break;

    case 'monthly_sales':
        $sql = "SELECT DATE_FORMAT(s.sale_date, '%M %Y') AS period, SUM(si.total) AS value
                    FROM sale_items si
                    JOIN sales s ON si.sale_id = s.sale_id
                    WHERE 1";
        if ($startDate && $endDate) {
            $sql .= " AND s.sale_date BETWEEN :start AND :end";
        }
        $sql .= " GROUP BY period ORDER BY MIN(s.sale_date)";
        $stmt = $pdo->prepare($sql);
        if ($startDate && $endDate) {
            $stmt->bindParam(':start', $startDate);
            $stmt->bindParam(':end', $endDate);
        }
        $label = 'Monthly Sales Trend';
        break;

    case 'weekly_sales':
        $sql = "SELECT DATE_FORMAT(s.sale_date, '%d/%m/%Y') AS period, SUM(si.total) AS value
                    FROM sale_items si
                    JOIN sales s ON si.sale_id = s.sale_id
                    WHERE 1";
        if ($startDate && $endDate) {
            $sql .= " AND s.sale_date BETWEEN :start AND :end";
        } else {
            $sql .= " AND s.sale_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
        }
        $sql .= " GROUP BY DATE(s.sale_date) ORDER BY s.sale_date ASC";
        $stmt = $pdo->prepare($sql);
        if ($startDate && $endDate) {
            $stmt->bindParam(':start', $startDate);
            $stmt->bindParam(':end', $endDate);
        }
        $label = 'Weekly Sales Trend';
        break;

    case 'low_stock':
        $stmt = $pdo->prepare("SELECT product_title AS label, in_stock AS value FROM products WHERE in_stock <= 10 ORDER BY in_stock ASC");
        $label = 'Low Stock Products';
        break;

    case 'stock_by_category':
        $stmt = $pdo->prepare("SELECT c.category_name AS label, SUM(p.in_stock) AS value FROM products p JOIN category c ON p.category_id = c.category_id GROUP BY c.category_name");
        $label = 'Stock by Category';
        break;

    case 'top_category_sales':
        $stmt = $pdo->prepare("SELECT c.category_name AS label, SUM(si.total) AS value FROM sale_items si JOIN products p ON si.product_id = p.product_id JOIN category c ON p.category_id = c.category_id GROUP BY c.category_name ORDER BY value DESC");
        $label = 'Top Categories by Sales';
        break;

    case 'no_sales':
        $stmt = $pdo->prepare("SELECT p.product_title AS label, 0 AS value FROM products p LEFT JOIN sale_items si ON p.product_id = si.product_id WHERE si.product_id IS NULL");
        $label = 'Products with No Sales';
        break;

    default:
        $stmt = $pdo->prepare("SELECT p.product_title, SUM(si.total) AS value FROM sale_items si JOIN products p ON si.product_id = p.product_id GROUP BY si.product_id ORDER BY value DESC LIMIT 10");
        $label = 'Top Product Sales (Revenue)';
        break;
}

$stmt->execute();
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

$response = [
    'labels' => array_column($data, isset($data[0]['product_title']) ? 'product_title' : (isset($data[0]['label']) ? 'label' : 'period')),
    'values' => array_column($data, 'value'),
    'label' => $label
];

header('Content-Type: application/json');
echo json_encode($response);
