<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = $_POST['product_id'];
    $quantity = (int) $_POST['quantity'];

    include 'db.php';

    // Fetch the product details
    $stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product) {
        $in_stock = (int) $product['in_stock']; // Ensure stock is treated as an integer

        // Check if the product is out of stock
        if ($in_stock <= 0) {
            $_SESSION['message'] = [
                'type' => 'danger',
                'text' => "This product is out of stock."
            ];
        } else {
            $current_quantity = isset($_SESSION['cart'][$product_id]) ? $_SESSION['cart'][$product_id]['quantity'] : 0;
            $new_quantity = $current_quantity + $quantity;

            // Ensure the user cannot add more than the available stock
            if ($new_quantity > $in_stock) {
                $_SESSION['message'] = [
                    'type' => 'danger',
                    'text' => "Only $in_stock units of '{$product['product_title']}' are available."
                ];
            } else {
                $_SESSION['cart'][$product_id] = [
                    'product_id' => $product['product_id'],
                    'product_title' => $product['product_title'],
                    'selling_price' => $product['selling_price'],
                    'quantity' => $new_quantity,
                    'total' => $product['selling_price'] * $new_quantity
                ];

                $_SESSION['message'] = [
                    'type' => 'success',
                    'text' => "{$product['product_title']} added to cart successfully!"
                ];
            }
        }
    } else {
        $_SESSION['message'] = [
            'type' => 'danger',
            'text' => "Product not found."
        ];
    }

    header("Location: new_sales.php");
    exit();
}
?>
