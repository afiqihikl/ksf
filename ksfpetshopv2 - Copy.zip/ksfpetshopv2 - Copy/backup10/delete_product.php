<?php
session_start();
include 'db.php';
include 'toast.php';
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $product_id = intval($_GET['id']);

    try {
        // Prepare delete query
        $query = "DELETE FROM products WHERE product_id = :product_id";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->execute();

        // Redirect with success message
        $_SESSION['toast_message'] = "Product deleted successfully!";
        $_SESSION['toast_type'] = "success";
    } catch (PDOException $e) {
        // Redirect with error message
        $_SESSION['toast_message'] = "Error deleting product: " . $e->getMessage();
        $_SESSION['toast_type'] = "danger";
    }
} else {
    // Redirect if ID is not valid
    setToast('danger', 'Invalid product ID.');
    $_SESSION['toast_message'] = "Invalid product ID.";
    $_SESSION['toast_type'] = "danger";
}
// Redirect to category.php
header("Location: product.php");
exit;