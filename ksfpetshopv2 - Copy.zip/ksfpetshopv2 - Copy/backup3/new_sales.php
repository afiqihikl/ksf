<?php
// session_start(); // Start session to access messages                 
include 'db.php'; // Ensure this path is correct
include 'sidebar.php';

// Check if a search term was submitted
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$query = "SELECT p.product_code, p.product_id, p.product_title, p.selling_price, p.in_stock, 
                 c.category_name, v.vendor_name 
          FROM products p
          JOIN category c ON p.category_id = c.category_id
          JOIN vendors v ON p.vendor_id = v.vendor_id";

$params = [];

if (!empty($search)) {
    $query .= " WHERE p.product_title LIKE :search OR p.product_code LIKE :search";
    $params[':search'] = "%$search%";
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">SALES</h1>

        <div class="row">
            <div class="col-12">
                <form action="" method="GET">
                    <div class="input-group">
                        <input type="text" id="searchInput" class="form-control" placeholder="Search..." onkeyup="searchTable('myTable', 'searchInput')">
                    </div>
                </form>
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-<?= $_SESSION['message']['type'] ?> alert-dismissible fade show mt-3 mx-3" role="alert">
                        <?= $_SESSION['message']['text'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['message']); // Clear message after displaying 
                    ?>
                <?php endif; ?>
                <div class="card mt-4" style="height:100%">
                    <div class="card-header">
                        <div class="row">
                            <div class="col d-flex justify-content-start">
                                ADD SALES
                            </div>
                            <div class="d-flex justify-content-end">
                                <button type="button" class="btn btn-primary" onclick="window.location='scanner_sales.php'"><i class='fa fa-plus-circle'></i> Scanner</button>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-sm">
                            <table class="table table-bordered" id="myTable">
                                <thead>
                                    <tr>
                                        <th>Product Title</th>
                                        <th>Product Code</th>
                                        <th>Category Name</th>
                                        <th>Vendor Name</th>
                                        <th>Selling Price</th>
                                        <th>In Stock</th>
                                        <th>Qty</th>
                                        <th>Total</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($products): ?>
                                        <?php foreach ($products as $product): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($product['product_title']) ?></td>
                                                <td><?= htmlspecialchars($product['product_code']) ?></td>
                                                <td><?= htmlspecialchars($product['category_name']) ?></td>
                                                <td><?= htmlspecialchars($product['vendor_name']) ?></td>
                                                <td class="selling-price"><?= htmlspecialchars($product['selling_price']) ?></td>
                                                <td><?= htmlspecialchars($product['in_stock']) ?></td>
                                                <td>
                                                    <form action="add_to_sales.php" method="POST">
                                                        <div class="input-group quantity-container" style="max-width: 150px;">
                                                            <input type="hidden" name="product_id" value="<?= $product['product_id'] ?>">
                                                            <button class="btn btn-outline-secondary decrease" type="button">-</button>
                                                            <input type="number" name="quantity" class="form-control text-center qty-input" min="1" value="1" required>
                                                            <button class="btn btn-outline-secondary increase" type="button">+</button>

                                                        </div>
                                                </td>
                                                <td class="total-price">0.00</td> <!-- This will be updated dynamically -->
                                                <td>
                                                    <button type="submit" class="btn btn-primary">Add to Cart</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No products found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Select all rows
            document.querySelectorAll("tr").forEach(row => {
                let qtyInput = row.querySelector(".qty-input"); // Find quantity input in the row
                let priceElement = row.querySelector(".selling-price"); // Find price element
                let totalPriceElement = row.querySelector(".total-price"); // Find total price element
                let increaseBtn = row.querySelector(".increase"); // Select increase button
                let decreaseBtn = row.querySelector(".decrease"); // Select decrease button

                // Ensure elements exist in the row before adding event listeners
                if (!qtyInput || !priceElement || !totalPriceElement || !increaseBtn || !decreaseBtn) return;

                let price = parseFloat(priceElement.textContent); // Get product price

                // Function to update total price
                function updateTotal() {
                    let qty = parseInt(qtyInput.value) || 1; // Ensure qty is at least 1
                    let total = price * qty;
                    totalPriceElement.textContent = total.toFixed(2); // Update total price in the row
                }

                // Increase Button (+)
                increaseBtn.addEventListener("click", function() {
                    qtyInput.value = parseInt(qtyInput.value) + 1;
                    updateTotal();
                });

                // Decrease Button (-)
                decreaseBtn.addEventListener("click", function() {
                    if (qtyInput.value > 1) {
                        qtyInput.value = parseInt(qtyInput.value) - 1;
                        updateTotal();
                    }
                });

                // Input Change (Manual typing)
                qtyInput.addEventListener("input", updateTotal);

                // Initialize total price on page load
                updateTotal();
            });
        });


        function searchTable(tableId, inputId) {
            let input = document.getElementById(inputId);
            let filter = input.value.toLowerCase();
            let table = document.getElementById(tableId);
            let rows = table.getElementsByTagName("tr");

            for (let i = 1; i < rows.length; i++) {
                let cells = rows[i].getElementsByTagName("td");
                let rowContainsFilter = false;

                for (let j = 0; j < cells.length; j++) {
                    if (cells[j].innerText.toLowerCase().includes(filter)) {
                        rowContainsFilter = true;
                        break;
                    }
                }

                rows[i].style.display = rowContainsFilter ? "" : "none";
            }
        }
        document.addEventListener("DOMContentLoaded", function() {
            // Automatically close alert message after 3 seconds
            setTimeout(function() {
                let alert = document.querySelector(".alert");
                if (alert) {
                    alert.style.transition = "opacity 0.5s";
                    alert.style.opacity = "0";
                    setTimeout(() => alert.remove(), 200); // Remove from DOM after fading out
                }
            }, 3000);
        });
    </script>


</body>

</html>