<?php
ob_start(); // Start output buffering
include 'db.php';
include 'sidebar.php';
include 'toast.php'; // Include toast functions

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $category_id = $_POST['category'];
    $vendor_id = $_POST['vendor_name'];
    $in_stock = $_POST['in_stock'];
    $buying_price = $_POST['buying_price'];
    $selling_price = $_POST['selling_price'];
    $image_path = '';

    // Generate a unique 8-digit product code
    function generateUniqueProductCode($pdo)
    {
        do {
            $product_code = str_pad(mt_rand(0, 99999999), 8, '0', STR_PAD_LEFT);
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE product_code = ?");
            $stmt->execute([$product_code]);
            $exists = $stmt->fetchColumn();
        } while ($exists);

        return $product_code;
    }

    $product_code = generateUniqueProductCode($pdo);

    // Handle file upload
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "uploads/";
        $image_name = basename($_FILES['product_image']['name']);
        $target_file = $target_dir . time() . "_" . $image_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($imageFileType, $allowed_types)) {
            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file)) {
                $image_path = $target_file;
            }
        }
    }

    // Insert data into database with generated product_code
    try {
        $stmt = $pdo->prepare("INSERT INTO products (product_code, photos, product_title, category_id, vendor_id, in_stock, buying_price, selling_price) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$product_code, $image_path, $title, $category_id, $vendor_id, $in_stock, $buying_price, $selling_price]);
        setToast('success', 'Product added successfully!');
    } catch (PDOException $e) {
        setToast('danger', 'Error adding product: ' . $e->getMessage());
    }

    header("Location: product.php");
    exit();
}

ob_end_flush();

// Fetch categories from the database
$categories = $pdo->query("SELECT * FROM category")->fetchAll(PDO::FETCH_ASSOC);
// Fetch vendors from the database
$vendors = $pdo->query("SELECT * FROM vendors")->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KSF PET SHOP - Add Product</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="content" id="content">
        <h1 class="mt-4">PRODUCT</h1>
        <div class="card mt-4">
            <div class="card-header">Add New Product</div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Product Title" name="title" required>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <select class="form-control" name="category" required>
                                    <option value="" disabled selected>Select Category</option>
                                    <?php foreach ($categories as $category) : ?>
                                        <option value="<?= $category['category_id'] ?>"><?= htmlspecialchars($category['category_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" name="product_image" accept="image/*">
                                    <label class="custom-file-label">Choose file</label>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <select class="form-control" name="vendor_name" required>
                                    <option value="" disabled selected>Select Vendor</option>
                                    <?php foreach ($vendors as $vendor) : ?>
                                        <option value="<?= $vendor['vendor_id'] ?>"><?= htmlspecialchars($vendor['vendor_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <input type="number" class="form-control" placeholder="Product Quantity" name="in_stock" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <input type="number" class="form-control" placeholder="Buying Price" name="buying_price" step="any" min="0" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <input type="number" class="form-control" placeholder="Selling Price" name="selling_price" step="any" min="0" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>