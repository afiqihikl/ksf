<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $vendor_id = $_POST['vendor_id'];
        $vendor_name = $_POST['vendor_name'];
        $vendor_status = $_POST['vendor_status'];
        $vendor_contact = $_POST['vendor_contact'];
        $vendor_address = $_POST['vendor_address'];
        $vendor_personincharge = $_POST['vendor_personincharge'];

        $sql = "UPDATE vendors 
                SET vendor_name = :vendor_name, 
                    vendor_status = :vendor_status, 
                    vendor_contact = :vendor_contact, 
                    vendor_address = :vendor_address, 
                    vendor_personincharge = :vendor_personincharge 
                WHERE vendor_id = :vendor_id";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':vendor_id' => $vendor_id,
            ':vendor_name' => $vendor_name,
            ':vendor_status' => $vendor_status,
            ':vendor_contact' => $vendor_contact,
            ':vendor_address' => $vendor_address,
            ':vendor_personincharge' => $vendor_personincharge
        ]);

        // Redirect with success message
        header("Location: vendor.php?success=Vendor updated successfully!");
        exit();
    } catch (PDOException $e) {
        // Redirect with error message
        header("Location: vendor.php?error=Error updating vendor: " . $e->getMessage());
        exit();
    }
} else {
    // Redirect if accessed directly
    header("Location: vendor.php");
    exit();
}
?>
